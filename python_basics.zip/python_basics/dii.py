#Dictionary in Python
fruit={"Apple":10,"Orange":20,"Banana":30,"Guava":40}
print(fruit.keys())


fruit={"Apple":10,"Orange":20,"Banana":30,"Guava":40}
print(fruit.values())


fruit={"Apple":10,"Orange":20,"Banana":30,"Guava":40}
fruit["Mango"]=50

fruit3={"Apple":10,"Orange":20,"Banana":30,"Guava":40,"Mango":50}
fruit3["Apple"]=100
print(fruit3)

#Using update() method
fruit1={"Apple":10,"Orange":20}
fruit2={"Banana":30,"Guava":40,"Apple":50}
fruit1.update(fruit2)
print(fruit1)

#Using ** operator
fruit1={"Apple":10,"Orange":20}
fruit2={"Banana":30,"Guava":40,"Apple":50}
fruit4= {**fruit1,**fruit2}
print(fruit4)


#Using collection.ChainMap() method
from collections import ChainMap
dict_1={'John': 15, 'Rick': 10, 'Misa' : 12 }
dict_2={'Bonnie': 18,'Rick': 20,'Matt' : 16 }
dict_3 = ChainMap(dict_1, dict_2)
print(dict_3)
print(dict(dict_3))



fruit={"Apple":10,"Orange":20,"Banana":30,"Guava":40}
fruit.pop("Orange")
print(fruit)