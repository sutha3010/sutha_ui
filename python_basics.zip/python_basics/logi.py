#Logical Operators
a=True
b=False
print(a&b)

print(b&a)

print(b&b)

print(a&a)

print(a|b)

print(b|a)

print(a|a)

print(b|b)