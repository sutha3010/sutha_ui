#local scope
def scope():
     str="sutha"
     print(str)
scope()

#Function Inside Function
#The local variable can be accessed from a function within the function:
def func():
    str="veni"
    def inner_func():
        print(str)
    inner_func()
func()

#Global Scope
#A variable created outside of a function is global and can be used by anyone:
str="suthaveni"
def glo():
    print(str)
    glo()
print(str)

# the same variable name inside and outside of a function
#The function will print the local x, and then the code will print the global x:
x = 300
def myfunc():
  x = 200
  print(x)
myfunc()
print(x)


#Global Keyword
def glob():
    global str
    str = "trainee"
glob()
print(str)