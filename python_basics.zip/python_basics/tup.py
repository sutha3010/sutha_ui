#Tuples in Python
tup1=(1,"a",True,2,"b",False)
print(tup1)


print(tup1[0])

print(tup1[-1])

tup1=(1,"a",True,2,"b",False)
print(tup1[1:4])

print(tup1[1:4])
tup1[1:4]

print(tup1[1:4])

# tup1[2]="hello"


# tup1[6]=3+4j


tup1=(1,"a",True,2,"b",False)
print(len(tup1))

tup1 = (1,"a",True)
tup2 = (4,5,6)
print(tup2+tup1)

tup1 = ('sparta',300)
tup2 = (4,5,6)
print(tup1*3 + tup2)

tup1=(1,2,3,4,5)
print(min(tup1))

tup1=(1,2,3,4,5)
print(max(tup1))

