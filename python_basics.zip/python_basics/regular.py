import  re

import camelcase

pattern ='^s...a$'
str ="sutha"
result = re.match(pattern,str)
if result:
     print("your name is there")
else:
     print("soryy cant find your name")

#findall
str = input("Enter the string: ")
pattern = re.findall('th',str)
result = re.findall("\s",str)
x= re.split("\s",str)
#Split the string only at the first occurrence:
x1= re.split("\s",str,1)
#Replace the one occurrence of a white-space character with !!:
y= re.sub("\s","!!",str)
##Return a match at every word character (characters from a to Z, digits from 0-9, and the underscore _ character):
z=re.findall("\w",str)
#Check if the string has other characters than t,e, r
m=re.findall("[^ter]",str)
print(pattern)
print(result)
print(x)
print(x1)
print(y)
print(z)
print(m)


#camelcase using pip
txt="terabase is a software"
c = camelcase.CamelCase()
print(c.hump(txt))


#exception handling
try:
  print("Hello")
except:
  print("Something went wrong")
else:
  print("Nothing went wrong")