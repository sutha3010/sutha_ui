import pandas as pd
df = pd.read_json('customer.json')
print(df)