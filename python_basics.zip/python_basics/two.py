#Mean and Median- Write a function that takes in a list of numbers, computes the mean and median, and returns True if the median value is greater than the mean of the numbers. Otherwise, return False.

def mean_median(scores):
	mean=sum(scores)/len(scores)
	median=sorted(scores)[int(len(scores)/2)]
	if median>mean: return True
	return False


scores=([3,4,3,2,9,7,11,12,13])

