#Variables
var1="John"
print(var1)

var2="Sam"
print(var2)

var3="Matt"
print(var3)

