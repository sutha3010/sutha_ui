import  math
x = math.sqrt(22)
x1 = math.ceil(1.4)
y = math.floor(1.4)
z = math.pi
print(x)
print(x1)
print(y)
print(z)

