class person:
    def __init__(self, city, age):
        self.city = city
        self.age = age
obj = person("tvl", "22")
print(obj.city)

#class with function

class birds:
    def __init__(self, name, color):
        self.name = name
        self.color=color
    def func(self):
        print(self.name, self.color)
obj = birds("parrot","green")
obj.func()


