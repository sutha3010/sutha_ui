import  module
a = module.person1["age"]
print(a)
#create an alias
import module as md
a = md.person1["name"]
print(a)

#built-in
import platform
x = platform.system()
print(x)

#Using the dir() Function
import platform
x = dir(platform)
print(x)

from module import person1
print (person1["country"])
