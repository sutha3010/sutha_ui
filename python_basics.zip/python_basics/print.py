print("hi this is sutha , MCA student")


#indentation

x = 1
if x ==1:
    print("x is equal to 1.")

print("Hello, World!")


a\
   =\
   10

a

"""Hi
How are you?"""

"Hi\
How are you?"

#This is a comment

if 2>1:
	print("Yes")

"I'm fine"

s="I'm fine"

print(s)

score=96

print(f"I scored a {score} on the Spanish test")

