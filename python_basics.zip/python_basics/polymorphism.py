#Class Polymorphism
class boat:
    def __init__(self,name,color):
        self.name = name
        self.color = color
    def move(self):
        print("this is a boat")
class bike:
    def __init__(self,name,color):
        self.name = name
        self.color = color
    def move(self):
        print("this is a bike")
class plane:
    def __init__(self, name, color):
        self.name = name
        self.color = color
    def move(self):
        print("this is a plane")

boat1 = boat("suzuki","pink")
bike1 = bike("apache","white")
plane1 = plane("indigo","red")
for x in (boat1,bike1,plane1):
    x.move()

#inheritance class polymorphism

class college:
    def __init__(self,name,roll):
        self.name = name
        self.roll = roll
    def study(self):
        print("successfully executed inheritance class polymorphism!!!!")

class teacher(college):
    pass
class student(college):
    pass
class books(college):
    pass

teacher1 = teacher("stc","404")
student1 = student("sutha","023")
book1 = books("python","100")
for x in (teacher1,student1,book1):
     print(x.name)
     print(x.roll)
     x.study()



