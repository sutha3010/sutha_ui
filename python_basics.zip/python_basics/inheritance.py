# single inheritance
class animals:
    def __init__(self,name,color):
        self.name = name
        self.color = color
    def function(self):
        print(self.name,self.color)
class wild_animals(animals):
    pass
obj=wild_animals("lion","brown")
obj.function()


#multiple inheritance
class father:
    def __init__(self,fname,lname):
        self.fname = fname
        self.lname = lname
    def funct(self):
        print(self.fname,self.lname)

class mother:
    def __init__(self,fname,lname):
        self.fname = fname
        self.lname = lname
    def funct(self):
        print(self.fname,self.lname)

class son(father,mother):
    def fun(self):
        print(self.fname)
        print(self.lname)
obj = son("sutha","veni")
obj.funct()




