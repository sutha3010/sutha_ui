#Strings
my_string="My name is John"
print(my_string[0])


my_string="My name is John"
print(my_string[-1])

print(my_string[0:4])

print(len(my_string))

print(my_string.lower())

print(my_string.upper())

print(my_string.replace('y','a'))

new_string = "hello hello world"
print(new_string.count("hello"))

s1 = 'This is sparta!!!'
print(s1.find('sparta'))

print(s1.find('b'))

fruit = 'I like apples, mangoes, bananas'
print(fruit.split(','))



