#List in Python
l1=[1,"a",2,"b",3,"c"]
print(l1[1])

l1=[1,"a",2,"b",3,"c"]
print(l1[2:5])

l1=[1,"a",2,"b",3,"c"]
l1[0]=100
print(l1)


l1=[1,"a",2,"b",3,"c"]
l1.append("Sparta")
print(l1)

l1=[100, 'a', 2, 'b', 3, 'c', True]

print(l1.pop())


l1.insert(1,"Sparta")
print(l1)

l2 = ["mango","banana","guava","apple"]
print(l2.sort())


l1 = [1,2,3]
l2 = ["a","b","c"]
print(l1+l2)

l1 = [1,"a",True]
print(l1*3)

