import pandas
import pandas as pd
# data = {
#     "Day": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
#     "Visitors": [18, 26, 18, 18, 9, 9, 20, 30, 16, 24],
#     "Bounce_Rate": [77.27, 74.07, 73.68, 65, 90, 70, 72, 62.16, 81.25, 72],
# }
# myvar = pd.DataFrame(data)
# print(myvar)

#series
#pandas Series from a list:
a=[1,2,6,8,7]
var= pd.Series(a,index = ["x", "y", "z","n","m"])
print(var["m"])


#Pandas Series from a dictionary:
food ={"veg":400,"non_veg":200,"dessert":"kajukatli"}
menu = pd.Series(food,index=["dessert","veg"])
print(menu)

#DataFrame from two Series:
data = {
  "calories": [420, 380, 390],
  "duration": [50, 40, 45]
}
#Add a list of names to give each row a name:
myvar = pd.DataFrame(data,index=["day1","day2","day3"])
# print(myvar.loc[[0,1]])
print(myvar.loc["day3"])

# print(myvar)
import pandas as pd
df = pd.read_csv('data.csv')
#Pandas will only return the first 5 rows, and the last 5 rows:
print(df)
# print(df.to_string())
# print(pd.options.display.max_rows)


