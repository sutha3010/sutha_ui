mystr = "sutha"
myit = iter(mystr)

print(next(myit))
print(next(myit))
print(next(myit))
print(next(myit))
print(next(myit))

#Looping Through an Iterator
name =("sutha","subash","kamali")
for x in name:
     print(x)