import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ComparePopupComponent } from './compare-popup.component';

describe('PopupComponent', () => {
  let component: ComparePopupComponent;
  let fixture: ComponentFixture<ComparePopupComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ComparePopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComparePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
