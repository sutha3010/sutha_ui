import { Component, OnInit, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { CommonServiceService } from '../common-service/common-service.service';
import { Router } from '@angular/router';
import { ArcgisMapService } from '../service/arcgis-map.service';
import { DialogComponent } from '../dialog/dialog.component';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { CookieService } from 'ngx-cookie-service';
import { GeocodeService } from '../service/geocode.service';
import { MatGridListModule } from '@angular/material/grid-list';
import { KeyValue } from '@angular/common';
import { ExcelService } from './scenerio-comparsion-excel.service';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { round } from 'lodash';
import { ComparePopupProperties } from './compare-popup';

interface ParentContainer {
  showChildren: boolean;
  header: string;
}

@Component({
  selector: 'app-compare-popup',
  templateUrl: './compare-popup.component.html',
  styleUrls: ['./compare-popup.component.css'],
  animations: [
    trigger('fadeInOut', [
      state('in', style({ opacity: 1 })),
      transition('void => *', [
        style({ opacity: 0 }),
        animate(300)
      ]),
      transition('* => void', [
        animate(300, style({ opacity: 0 }))
      ])
    ])
  ]
})

export class ComparePopupComponent implements OnInit {
  @ViewChild('content') comparePopup:ElementRef;
  public thisService:CommonServiceService;
  compareScenario = [];
  initialURL:string = window.location.origin;
// initialURL:string = "http://localhost:8000";

  constructor(Webservice:CommonServiceService,public excelService: ExcelService,public cookieService: CookieService,public geocodeService: GeocodeService,public router:Router,public arcgisService:ArcgisMapService,public dialog: MatDialog,private renderer: Renderer2, private comparePopupProperties: ComparePopupProperties) {
    this.thisService = Webservice;
    this.arcgisService.popupComponent = this;
  }

  ngOnInit() {
    this.keyArray = this.comparePopupProperties.propertiesList
  }

  isShow = true;
  isShowResult = true;
  isShowContent = true;
  showSecondRows:boolean = false
  scenarioCount = 0
  rackingName;
  module_type;
  projectName;
  city;
  state;
  location;
  simDynamoOBJ
  simId;
  ppProjectID;
  keyArray;


  // ##### --- Racking properties - START --- #####

  //PV Modules properties
  widthGap = '-'
  heightGap = '-'

  //String info properties
  pvModulesPerStringEw = '-'
  pvModulesPerStringNs = '-'
  pvModulesPerString = '-'

  //Table info properties
  noOfPvModulesPerRows = '-'
  noOfPvModulesPerColumns = '-'
  motorTableGap = '-'
  gapBetweenTables = '-'
  gapBetweenRacks = '-'
  minimumPileReveal = '-'
  maxTtAxisSlope = '-'
  embedment = '-'
  revealWindow = '-'
  maximumSlopeChange = '-'
  typicalPileSize = '-'
  noOfStringsPerFullTracker = '-'
  noOfModulesPerFullTracker = '-'
  noOfPilesPerFullTracker = '-'
  noOfStringsPerPartialTracker = '-'
  noOfModulesPerPartialTracker = '-'
  noOfPilesPerPartialTracker = '-'
  pilesPerTable = '-'
  maxEwBeamSlope = '-'

  //Orientation properties
  pvModuleTiltMin = '-'
  pvModuleTiltMax = '-'
  enableBacktracking = '-'

  // ##### --- Racking properties - END --- #####

  header=[];
  comparisonHeader = [];
  subHeaders: string[] = ['PV Module', 'Racking', 'Inverter', 'Design', 'PV modules', 'String info', 'Table info', 'Orientation']
  subSubHeaders: string[] = ['PV modules', 'String info', 'Table info', 'Orientation']
  boqValues = ["noOfModulesPerBlock", "dcFeederLength", "dcFeederTrenches", "noOfStringsPerAcBlock", "oneWayStringLength", "noOfDcDisconnect", "quantityOfAcStation", "noOfPiles", "stringLength", "NoOfTracker", "totalNoOfRacksInv1"]
  parentContainers: ParentContainer[] = [
    { showChildren: false, header: 'User inputs' },
    { showChildren: false, header: 'Analysis output' },
    { showChildren: false, header: 'BoQ output' },
    { showChildren: false, header: 'Configuration details' }
  ];

  originalOrder = (a: KeyValue<number, string>, b: KeyValue<number, string>): number => {
    return 0;
  } 

  displayCompareJson={
    "ScenarioComparison":[]
  }

  show() {
    this.isShowContent = false;
    this.renderer.setStyle(this.comparePopup.nativeElement, "display", "block");
  }

  hide() {
    this.renderer.setStyle(this.comparePopup.nativeElement, "display", "none");
  }


  displayListToCompare() {
    if (this.isShowResult) {
      this.isShow = false;
      this.isShowContent = true;
    }
    this.compareScenario.push(this.arcgisService.simulationComponent.compareScenarioList);
    this.arcgisService.simulationComponent.compareScenarioList = [];
  }

  getData(simDynamoObj, scenarioId) {
    var data
    simDynamoObj.filter(x => {
      if (x.scenarioID == scenarioId) {
        data = x
      }
    })

    return data
  }

  compareListValues(SimDynamoOBJ, scenarioID) {
    this.resetPropertyValues()
    var scenarioId = {
      "id": ''
    }

    scenarioId["id"] = scenarioID;
    this.simDynamoOBJ = this.arcgisService.simulationComponent.simDynamoObj
    var Scenarios = this.getData(this.arcgisService.simulationComponent.simDynamoObj.scenariosFullDynamoData, scenarioID)
    Scenarios.roadArea = (parseInt(Scenarios.roadArea));
    Scenarios.perimeterRoadArea = 'perimeterRoadArea' in Scenarios ? (parseInt(Scenarios.perimeterRoadArea)) : '-'
    Scenarios.totalRoadArea = 'totalRoadArea' in Scenarios ? (parseInt(Scenarios.totalRoadArea)) : 'totalInternalRoadAreas' in Scenarios ? this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['totalInternalRoadAreas'], scenarioId, 'totalInternalRoadAreas') : '-'
    var moduleOrien = this.simDynamoOBJ.inputs.productData.modOrientation == 1 ? "Portrait" : "Landscape";
    var noOfTrackersExcludeExtraRacks: any = this.simDynamoOBJ.scenariosFullDynamoData[scenarioID]['NoOfTrackers'] - Scenarios['Extra No. of Racks to Fade']

    var totalNoOfTables
    var totalNoOfTablesInv1    

    this.setCommonPropertyValues()

    if (this.simDynamoOBJ.inputs['trackerType'] == "genericTracker") {
      this.setGenericTrackerPropertyValues()
      this.setGenericAndGftCommonPropertyValues()
    }
    
    if (this.simDynamoOBJ.inputs['trackerType'] == "gft") {
      this.setGenericAndGftCommonPropertyValues()
      this.setGftTrackerPropertyValues()
    }

    if ('trackerType' in this.simDynamoOBJ.inputs) {
      if (this.simDynamoOBJ.inputs['trackerType'] == "1PMultiStringTracker") {
        var noOfFullTrackersExcludeExtraRacks = this.simDynamoOBJ.scenariosFullDynamoData[scenarioID]['noOfFullTrackers'] - this.simDynamoOBJ.scenariosFullDynamoData[scenarioID]['Extra No. of full tracker to Fade']
        var noOfPartialTrackersExcludeExtraRacks = this.simDynamoOBJ.scenariosFullDynamoData[scenarioID]['noOfPartialTrackers'] - this.simDynamoOBJ.scenariosFullDynamoData[scenarioID]['Extra No. of partial tracker to Fade']
        var numberOfModules = noOfFullTrackersExcludeExtraRacks * this.simDynamoOBJ.inputs['IPMultiStringDetails'].fullTrackers.modulesPerTracker +
          noOfPartialTrackersExcludeExtraRacks * this.simDynamoOBJ.inputs['IPMultiStringDetails'].partialTrackers.modulesPerTracker
        var numberOfString = noOfFullTrackersExcludeExtraRacks * this.simDynamoOBJ.inputs['IPMultiStringDetails'].fullTrackers.numOfStringsPerTracker +
          noOfPartialTrackersExcludeExtraRacks * this.simDynamoOBJ.inputs['IPMultiStringDetails'].partialTrackers.numOfStringsPerTracker
        var totalPilesCount = noOfFullTrackersExcludeExtraRacks * this.simDynamoOBJ.inputs['IPMultiStringDetails'].fullTrackers.pilesCount +
          noOfPartialTrackersExcludeExtraRacks * this.simDynamoOBJ.inputs['IPMultiStringDetails'].partialTrackers.pilesCount
        var stringsLength = this.simDynamoOBJ.inputs['IPMultiStringDetails'].fullTrackers.modulesPerString
        totalNoOfTables = noOfFullTrackersExcludeExtraRacks + noOfPartialTrackersExcludeExtraRacks
        totalNoOfTablesInv1 = noOfFullTrackersExcludeExtraRacks + noOfPartialTrackersExcludeExtraRacks
        this.set1pTrackerPropertyValues()
      } else {
        var numberOfModules = noOfTrackersExcludeExtraRacks * this.simDynamoOBJ.inputs.productData.table_rows * this.simDynamoOBJ.inputs.productData.table_column;
        var numberOfString = noOfTrackersExcludeExtraRacks * this.simDynamoOBJ.inputs.productData.strings;
        var totalPilesCount = noOfTrackersExcludeExtraRacks * this.simDynamoOBJ.inputs.piles_per_table
        var stringsLength = this.simDynamoOBJ.inputs.productData.stringLength
        totalNoOfTables = noOfTrackersExcludeExtraRacks//(this.simDynamoOBJ.scenariosFullDynamoData[scenarioID]["NoOfTrackers"])
        totalNoOfTablesInv1 = parseInt(this.simDynamoOBJ.scenariosFullDynamoData[scenarioID]["Total No. of Racks for Inv 1"])
      }
    } else {
      var numberOfModules = noOfTrackersExcludeExtraRacks * this.simDynamoOBJ.inputs.productData.table_rows * this.simDynamoOBJ.inputs.productData.table_column;
      var numberOfString = noOfTrackersExcludeExtraRacks * this.simDynamoOBJ.inputs.productData.strings;
      var totalPilesCount = noOfTrackersExcludeExtraRacks * this.simDynamoOBJ.inputs.piles_per_table
      var stringsLength = this.simDynamoOBJ.inputs.productData.stringLength
      totalNoOfTables = noOfTrackersExcludeExtraRacks  //(this.simDynamoOBJ.scenariosFullDynamoData[scenarioID]["NoOfTrackers"])
      totalNoOfTablesInv1 = parseInt(this.simDynamoOBJ.scenariosFullDynamoData[scenarioID]["Total No. of Racks for Inv 1"])
    }

    var scenarioDetails = {
      'gcr': Scenarios.gcr, 'dcac': Scenarios.DCAC, 'noOfModule': numberOfModules, 'noOfRacks': noOfTrackersExcludeExtraRacks, 'noOfStrings': numberOfString, 'noOfInverter1': this.arcgisService.simulationComponent.noOfHighRatedInv,
      'noOfInverter2': this.arcgisService.simulationComponent.noOfLowratingInv == undefined ? 0 : this.arcgisService.simulationComponent.noOfLowratingInv
    }

    var boqData = {}
    //Below code written by sonali for old projects assign inverter type as central
    if (this.simDynamoOBJ.inputs.inverters[0]['Inverter Type'] == undefined) {
      this.simDynamoOBJ.inputs.inverters[0]['Inverter Type'] = 'central'
    }
    if ('Inverter Type' in this.simDynamoOBJ.inputs.inverters[0]) {
      if (this.simDynamoOBJ.inputs.inverters[0]['Inverter Type'] == 'central') {
        // Creating  required json for central inverter sheets
        boqData['noOfModulesPerBlock'] = scenarioDetails["noOfModule"];
        boqData['stringLength'] = stringsLength //SimDynamoOBJ.inputs.productData.modperstringEW * SimDynamoOBJ.inputs.productData.modperstringNS;
        boqData['noOfStringsPerAcBlock'] = scenarioDetails["noOfStrings"];
        boqData['NoOfTracker'] = totalNoOfTables //SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["NoOfTrackers"];
        boqData['noOfPiles'] = totalPilesCount;
        boqData['totalNoOfRacksInv1'] = totalNoOfTablesInv1 //SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["Total No. of Racks for Inv 1"];
        boqData['Total No. of Racks for Inv 2'] = SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["Total No. of Racks for Inv 2"];
        boqData['oneWayStringLength'] = this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['totalDcStringCableLength'], scenarioId, 'totalDcStringCableLength'); //rackingSytemData.stringLength
        boqData['noOfDcDisconnect'] = SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["totalCombinerBox"];//array -- [scenarioID]
        boqData['dcFeederLength'] = this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['totalFeederlength'], scenarioId, 'totalFeederlength');//Scenarios["totalFeederlength"][0][0] --
        if (this.simDynamoOBJ.inputs.moduleSelectedData.cellTechnologyType == 'CdTe') {
          var totalDcTrenches = this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['dcFeederTrenchLength01'], scenarioId, 'dcFeederTrenchLength01') + this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['dcFeederTrenchLength06'], scenarioId, 'dcFeederTrenchLength06') + this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['dcFeederTrenchLength08'], scenarioId, 'dcFeederTrenchLength08')
        } else {
          var totalDcTrenches = this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['totalDcTrenchLengthHorizontal'], scenarioId, 'totalDcTrenchLengthHorizontal') + this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['totalDcTrenchLengthVertical'], scenarioId, 'totalDcTrenchLengthVertical')
        }
        boqData['dcFeederTrenches'] = totalDcTrenches
        boqData['quantityOfAcStation'] = this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['totalInverters'], scenarioId, 'totalInverters'); //---
        boqData['inverter1'] = scenarioDetails["noOfInverter1"];
        boqData['inverter2'] = scenarioDetails["noOfInverter2"];
        boqData['boundaryArea'] = SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["boundaryArea"];
        boqData['totalRoadArea'] = Scenarios.totalRoadArea
        boqData['roadArea'] = Scenarios.roadArea//(parseInt(SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["roadArea"]));
        boqData['perimeterRoadArea'] = Scenarios.perimeterRoadArea//(parseInt(SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["perimeterRoadArea"]));
        boqData['perimeterFence'] = SimDynamoOBJ.scenariosFullDynamoData[scenarioID].fenceLength.toFixed(2);
      } else {
        // Creating  required json for string inverter sheets
        boqData['noOfModulesPerBlock'] = scenarioDetails["noOfModule"];
        boqData['stringLength'] = stringsLength //SimDynamoOBJ.inputs.productData.modperstringEW * SimDynamoOBJ.inputs.productData.modperstringNS;
        boqData['noOfStringsPerAcBlock'] = scenarioDetails["noOfStrings"];
        boqData['NoOfTracker'] = totalNoOfTables //SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["NoOfTrackers"];
        boqData['noOfPiles'] = totalPilesCount;
        boqData['totalNoOfRacksInv1'] = totalNoOfTablesInv1 //SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["Total No. of Racks for Inv 1"];
        boqData['Total No. of Racks for Inv 2'] = SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["Total No. of Racks for Inv 2"];
        boqData['oneWayStringLength'] = this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['acStringCableLength'], scenarioId, 'acStringCableLength'); //rackingSytemData.stringLength
        boqData['noOfDcDisconnect'] = "-"//array -- [scenarioID]
        boqData['dcFeederLength'] = this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['totalFeederlength'], scenarioId, 'totalFeederlength');//Scenarios["totalFeederlength"][0][0] --
        var totalDcTrenches = this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['acTrenchLengthHorizontal'], scenarioId, 'acTrenchLengthHorizontal') + this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['acTrenchLengthVertical'], scenarioId, 'acTrenchLengthVertical')
        boqData['dcFeederTrenches'] = totalDcTrenches
        boqData['quantityOfAcStation'] = this.arcgisService.simulationComponent.sumOFArrayOfObject(SimDynamoOBJ.scenariosFullDynamoData[scenarioID]['totalInverters'], scenarioId, 'totalInverters'); //"-" 
        boqData['inverter1'] = scenarioDetails["noOfInverter1"];
        boqData['inverter2'] = scenarioDetails["noOfInverter2"];
        boqData['boundaryArea'] = SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["boundaryArea"];
        boqData['totalRoadArea'] = Scenarios.totalRoadArea
        boqData['roadArea'] = Scenarios.roadArea//(parseInt(SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["roadArea"]));
        boqData['perimeterRoadArea'] = Scenarios.perimeterRoadArea//(parseInt(SimDynamoOBJ["scenariosFullDynamoData"][scenarioID]["perimeterRoadArea"]));
        boqData['perimeterFence'] = SimDynamoOBJ.scenariosFullDynamoData[scenarioID].fenceLength.toFixed(2);
      }

      var json = {}
      json["scenarios"] = scenarioID
      json["simulation_name"] = this.simDynamoOBJ.inputs.simulationName
      var index = 0;

      Object.keys(this.keyArray).filter(heading => {
        json[heading] = {}
        this.keyArray[heading].filter(x => {
          var dataInput = this.simDynamoOBJ.inputs
          //  var Scenarios = this.simDynamoOBJ.scenarios[scenarioID]
          var scenariosFullData = Scenarios
          //Below condition written by sonali to display boundaryArea (sum of all boundaries) value from scenarioData instead of inputs.
          if (x.simDynamoTitle != "boundaryArea" && Object.keys(dataInput).includes(x.simDynamoTitle)) {
            if (dataInput[x.simDynamoTitle] != undefined) {
              if (x.simDynamoTitle == "weatherDataHeaderID") {
                let weatherFile = '';
                let weatherData = this.arcgisService.simulationComponent.simDynamoObj.inputs['weatherData'][0]
                if (this.arcgisService.simulationComponent.isPlantPredictProject == false) {
                  json[heading][x.title] = this.arcgisService.simulationComponent.simDynamoObj.inputs.weatherDataHeaderID
                } else if (weatherData.title !== undefined || weatherData.title !== '' || weatherData.title !== null) {
                  json[heading][x.title] = weatherData.title
                } else {
                  weatherFile = weatherData.stationName !== null ? weatherData.dataProviderValue + '-' + weatherData.stationName + weatherData.latitude.toFixed(2) + ',' + weatherData.longitude.toFixed(2) : weatherData.dataProviderValue + weatherData.latitude.toFixed(2) + ',' + weatherData.longitude.toFixed(2)

                  json[heading][x.title] = weatherFile
                }
              } else if (x.simDynamoTitle != "gcr") {
                if (x.simDynamoTitle == "trackerType") {
                  json[heading][x.title] = this.formatTrackerType(dataInput)
                } else {
                  json[heading][x.title] = dataInput[x.simDynamoTitle]
                }
              } else { json[heading][x.title] = scenariosFullData[x.simDynamoTitle][0] }
            }
          } else if (Object.keys(dataInput.productData).includes(x.simDynamoTitle)) {
            if (dataInput.productData[x.simDynamoTitle] != undefined) {
              if (x.simDynamoTitle != "modOrientation") {
                if (x.simDynamoTitle == "manufacturer_name" && dataInput.productData[x.simDynamoTitle] == "" && this.simDynamoOBJ.inputs.moduleSelectedData.manufacturer == "") {
                  json[heading][x.title] = '-'
                } else if (x.simDynamoTitle == "manufacturer_name" && dataInput.productData[x.simDynamoTitle] != "") {
                  json[heading][x.title] = dataInput.productData[x.simDynamoTitle]
                } else if (x.simDynamoTitle == "manufacturer_name" && this.simDynamoOBJ.inputs.moduleSelectedData.manufacturer != "") {
                  json[heading][x.title] = this.simDynamoOBJ.inputs.moduleSelectedData.manufacturer
                }

                if (x.simDynamoTitle == "module_skus" && dataInput.productData[x.simDynamoTitle] == "" && this.simDynamoOBJ.inputs.moduleSelectedData.model == "") {
                  json[heading][x.title] = '-'
                } else if (x.simDynamoTitle == "module_skus" && dataInput.productData[x.simDynamoTitle] != "") {
                  json[heading][x.title] = dataInput.productData[x.simDynamoTitle]
                } else if (x.simDynamoTitle == "module_skus" && this.simDynamoOBJ.inputs.moduleSelectedData.model != "") {
                  json[heading][x.title] = this.simDynamoOBJ.inputs.moduleSelectedData.model
                }
              }

              else {
                if (dataInput.productData[x.simDynamoTitle] == 1) {
                  json[heading][x.title] = "Portrait"
                } else {
                  json[heading][x.title] = "Landscape"
                }
              }
            }
          } else if (Object.keys(scenariosFullData).includes(x.simDynamoTitle)) {
            if (scenariosFullData[x.simDynamoTitle] != undefined) {
              if (!x.istoFixed) {
                json[heading][x.title] = scenariosFullData[x.simDynamoTitle]
              } else if (x.simDynamoTitle == "land_usage") {
                json[heading][x.title] = (scenariosFullData[x.simDynamoTitle] * 100).toFixed(1) + '%'
              } else if (scenariosFullData[x.simDynamoTitle] == '-') {
                json[heading][x.title] = scenariosFullData[x.simDynamoTitle]
              }
              else {
                json[heading][x.title] = scenariosFullData[x.simDynamoTitle].toFixed(2)
              }
            }
          } else if (scenariosFullData.perf != undefined && Object.keys(scenariosFullData.perf.summary).includes(x.simDynamoTitle)) {
            if (scenariosFullData.perf.summary[x.simDynamoTitle] != undefined) {
              if (!x.istoFixed) {
                json[heading][x.title] = scenariosFullData.perf.summary[x.simDynamoTitle]
              } else if (x.simDynamoTitle == "TotalInverterClippingLoss") {
                json[heading][x.title] = (scenariosFullData.perf.summary[x.simDynamoTitle] * 100).toFixed(2) + '%'
              } else {
                json[heading][x.title] = scenariosFullData.perf.summary[x.simDynamoTitle].toFixed(2)
              }
            }
          } else if ((this.boqValues).includes(x.simDynamoTitle)) {
            var i = 0
            var sum = 0
            Object.keys(boqData).filter(column => {
              var columns = column;
              if (column == x.simDynamoTitle) {
                if (Array.isArray(boqData[columns])) {
                  var sum = boqData[columns].reduce((a, b) => a + b, 0)
                  if (!isNaN(sum)) {
                    json[heading][x.title] = sum
                  } else { json[heading][x.title] = "-" }
                } else {
                  json[heading][x.title] = boqData[columns]
                }
              }
            })
          } else {
            if (x.simDynamoTitle == "inverter1") {
              json[heading][x.title] = scenariosFullData["No of HightRated Inverter"]
            } else if (x.simDynamoTitle == "inverter2") {
              json[heading][x.title] = scenariosFullData["No of Remaining Inverter"] == undefined ? 0 : scenariosFullData["No of Remaining Inverter"]
            } else if (x.simDynamoTitle == "Paco1") {
              if (this.simDynamoOBJ.inputs.inverterFamily == "Generic inverter" || this.simDynamoOBJ.inputs.inverterFamily == "Generic" + " " + this.simDynamoOBJ.inputs.inverters[0]["Inverter Type"] + " " + "inverter") {
                var paco;
                if (this.simDynamoOBJ.inputs['inverters'].length != undefined) {
                  paco = this.simDynamoOBJ.inputs['inverters'][0]['PacoGCE']
                } else {
                  paco = this.simDynamoOBJ.inputs.PacoGCE
                }
                json[heading][x.title] = paco / 1000
              } else { json[heading][x.title] = this.simDynamoOBJ.inputs.inverters[0].Paco / 1e6 }
            } else if (x.simDynamoTitle == "Paco2" && this.simDynamoOBJ.inputs.inverters[1] != undefined) {
              json[heading][x.title] = this.simDynamoOBJ.inputs.inverters[1].Paco / 1e6
            } else if (x.simDynamoTitle == "invManufacturer") {
              let id = this.simDynamoOBJ.inputs.inverters[0].id
              let inverter = this.arcgisService.simulationComponent.inverterApiData.filter(x => x.id == id)[0]
              json[heading][x.title] = inverter && inverter.manufacturer ? inverter.manufacturer : '-'
            } else if (x.simDynamoTitle == "modelName1") {
              if (this.simDynamoOBJ.inputs.inverterFamily == "Generic inverter" || this.simDynamoOBJ.inputs.inverterFamily == "Generic" + " " + this.simDynamoOBJ.inputs.inverters[0]["Inverter Type"] + " " + "inverter") {
                json[heading][x.title] = "Generic" + " " + this.simDynamoOBJ.inputs.inverters[0]["Inverter Type"] + " " + "inverter"
              } else { json[heading][x.title] = this.simDynamoOBJ.inputs.inverters[0].alias }
            } else if (x.simDynamoTitle == "absVoltage") {
              json[heading][x.title] = this.simDynamoOBJ.inputs.inverters[0].absoluteInverterVoltage
            } else if (x.simDynamoTitle == "powerFactor") {
              json[heading][x.title] = this.simDynamoOBJ.inputs.inverters[0].designDerate
            } else if (x.simDynamoTitle == "setPoint") {
              json[heading][x.title] = this.simDynamoOBJ.inputs.inverters[0].kVARating * this.simDynamoOBJ.inputs.inverters[0].designDerate
            } else if (x.simDynamoTitle == "modelName2" && this.simDynamoOBJ.inputs.inverters[1] != undefined) {
              json[heading][x.title] = this.simDynamoOBJ.inputs.inverters[1].modelName
            } else if (x.simDynamoTitle == "loosses") {
              json[heading][x.title] = this.simDynamoOBJ.inputs["lossesConfigVal"] == undefined ? "Standard" : this.simDynamoOBJ.inputs["lossesConfigVal"]
            } else if (x.simDynamoTitle == "satTiltAngle" && ['Custom Single-Axis Tracker', 'Custom Single axis tracker', 'Single-Axis Tracker', 'Single axis tracker'].includes(this.simDynamoOBJ.inputs.rackingName)) {// new values added by karthik as per matt changes
              json[heading][x.title] = this.simDynamoOBJ.inputs.productData.axisRotationMin + ' to ' + this.simDynamoOBJ.inputs.productData.axisRotationMax
            } else if (x.simDynamoTitle == "gftTiltAngle" && ['Custom Stationary Fixed Tilt (Ground)', 'Stationary Fixed Tilt (Ground)', 'Custom ground fixed tilt', 'Ground fixed tilt'].includes(this.arcgisService.simulationComponent.simDynamoObj.inputs.rackingName)) {// new values added by karthik as per matt changes
              if (scenariosFullData['perf'] && scenariosFullData['perf']['summary'] && scenariosFullData['perf']['summary']['axisTiltAngle']) {
                json[heading][x.title] = scenariosFullData['perf']['summary']['axisTiltAngle']
              } else {
                json[heading][x.title] = this.simDynamoOBJ.inputs.productData.axisTiltAngle
              }
            } else if (x.simDynamoTitle == "perimeterFence") { // new values added by karthik as per matt changes
              json[heading][x.title] = this.arcgisService.simulationComponent.simDynamoObj.scenariosFullDynamoData[(json["scenarios"])].fenceLength.toFixed(2);//"-" //this.arcgisService.simulationComponent.simDynamoObj.scenariosFullDynamoData[x].fenceLength.toFixed(2)//"-" //values need to be updated after discussion with giovanni
            } else if (x.simDynamoTitle == "2dYield") {
              if (this.arcgisService.simulationComponent.scenarios[(json["scenarios"])]["Yield"] == "failed") {
                json[heading][x.title] = "-"
              } else {
                json[heading][x.title] = this.arcgisService.simulationComponent.scenarios[(json["scenarios"])]["Yield"]//this.arcgisService.simulationComponent.simDynamoObj.scenarios[(json["scenarios"])].finance.yield.toFixed(2)
              }
            } else if (x.simDynamoTitle == "3dYield") {
              json[heading][x.title] = "N/A";
            } else if (scenariosFullData.finance != undefined && Object.keys(scenariosFullData.finance).includes(x.simDynamoTitle) && scenariosFullData.finance[x.simDynamoTitle] != undefined) {
              json[heading][x.title] = scenariosFullData.finance[x.simDynamoTitle]   //written by sonali to add epc cost and slcoe in table
            }
            else if (x.simDynamoTitle == 'pitch' || x.simDynamoTitle == 'aisle_spacing') {
              var rackWidth: any
              if (this.simDynamoOBJ.inputs.trackerType == '1PMultiStringTracker') {
                rackWidth = this.simDynamoOBJ.inputs.IPMultiStringDetails.trackerWidth
              } else {
                rackWidth = this.simDynamoOBJ.inputs.productData.xdim
              }

              var pitch: any = (parseFloat(rackWidth) / scenariosFullData['gcr'][0]).toFixed(2)
              if (x.simDynamoTitle == 'pitch')
                json[heading][x.title] = pitch
              else
                json[heading][x.title] = (pitch - parseFloat(rackWidth)).toFixed(2)

            } else {
              json[heading][x.title] = "-"
            }

          }
        })
      })

      let gcr = json['User inputs']['Specified GCR']
      let rowSpacing;
      let dcacRatio;
      let dcCapacity;
      let acCapacity;
      let dcacMin;
      let dcacMax;
      let inverterQty;


      let resultInputs = this.simDynamoOBJ.inputs.scenarioAnalysisResultInputs && this.simDynamoOBJ.inputs.scenarioAnalysisResultInputs.length >= 1 ? true : false
      if (!resultInputs) {
        gcr = '-'
        rowSpacing = '-'
        dcacRatio = '-'
        dcCapacity = '-'
        acCapacity = '-'
        dcacMin = '-'
        dcacMax = '-'
        inverterQty = '-'
      } else {
        let scenario = this.simDynamoOBJ.inputs.scenarioAnalysisResultInputs[scenarioID]
        gcr = scenario && Object.keys(scenario).length && scenario['scenarioAnalysisGcr'] != null && scenario['scenarioAnalysisGcr'] != undefined ? round(scenario['scenarioAnalysisGcr'], 3) : '-'
        rowSpacing = scenario && Object.keys(scenario).length && scenario['scenarioAnalysisRowSpacing'] != null && scenario['scenarioAnalysisRowSpacing'] != undefined ? round(scenario['scenarioAnalysisRowSpacing'], 3) : '-'
        dcacRatio = scenario && Object.keys(scenario).length && scenario['scenarioAnalysisDcAc'] != null && scenario['scenarioAnalysisDcAc'] != undefined ? round(scenario['scenarioAnalysisDcAc'], 3) : '-',
        dcCapacity = scenario && Object.keys(scenario).length && scenario['scenarioAnalysisDcCapacity'] != null && scenario['scenarioAnalysisDcCapacity'] != undefined ? round(scenario['scenarioAnalysisDcCapacity'], 3) : '-'
        acCapacity = scenario && Object.keys(scenario).length && scenario['scenarioAnalysisAcCapacity'] != null && scenario['scenarioAnalysisAcCapacity'] != undefined ? round(scenario['scenarioAnalysisAcCapacity'], 3) : '-'
        dcacMin = scenario && Object.keys(scenario).length && scenario['scenarioAnaylsisDCACMin'] != null && scenario['scenarioAnaylsisDCACMin'] != undefined ? round(scenario['scenarioAnaylsisDCACMin'], 3) : '-'
        dcacMax = scenario && Object.keys(scenario).length && scenario['scenarioAnaylsisDCACMax'] != null && scenario['scenarioAnaylsisDCACMax'] != undefined ? round(scenario['scenarioAnaylsisDCACMax'], 3) : '-'
        inverterQty = scenario && Object.keys(scenario).length && scenario['scenarioAnalysisInverterQuantity'] != null && scenario['scenarioAnalysisInverterQuantity'] != undefined ? round(scenario['scenarioAnalysisInverterQuantity'], 3) : '-'
      }

      let totalGrading = this.simDynamoOBJ.scenariosFullDynamoData[scenarioID] && this.simDynamoOBJ.scenariosFullDynamoData[scenarioID].terrainproAnalysisOutput ? this.simDynamoOBJ.scenariosFullDynamoData[scenarioID].terrainproAnalysisOutput['earthWorkData']['volume']['totalEarthWork'] : '-'

      //assign desin values
      json['User inputs']['Specified GCR'] = gcr ?? '-'
      json['User inputs']['Specified row spacing'] = rowSpacing ?? '-'
      json['User inputs']['Specified DC/AC ratio'] = dcacRatio ?? '-'
      json['User inputs']['Specified DC capacity (MW)'] = dcCapacity ?? '-'
      json['User inputs']['Specified AC capacity (MW)'] = acCapacity ?? '-'
      json['User inputs']['Specified inverter quantity'] = inverterQty ?? '-'
      json['User inputs']['Specified DC/AC Min'] = dcacMin ?? '-'
      json['User inputs']['Specified DC/AC Max'] = dcacMax ?? '-'

      //assign pv modules values
      json['User inputs']['Width gap'] = this.widthGap ?? '-'
      json['User inputs']['Height gap'] = this.heightGap ?? '-'

      //assign string info values
      json['User inputs']['PV modules per string EW'] = this.pvModulesPerStringEw ?? '-'
      json['User inputs']['PV modules per string NS'] = this.pvModulesPerStringNs ?? '-'
      json['User inputs']['PV modules per string'] = this.pvModulesPerString ?? '-'

      //assign table info values
      json['User inputs']['No. of PV modules per rows'] = this.noOfPvModulesPerRows ?? '-'
      json['User inputs']['No. of PV modules per columns'] = this.noOfPvModulesPerColumns ?? '-'
      json['User inputs']['Motor table gap [m]'] = this.motorTableGap ?? '-'
      json['User inputs']['Gap between tables [m]'] = this.gapBetweenTables ?? '-'
      json['User inputs']['Gap between racks [m]'] = this.gapBetweenRacks ?? '-'
      json['User inputs']['Minimum pile reveal [m]'] = this.minimumPileReveal ?? '-'
      json['User inputs']['Max TT-axis slope (º)'] = this.maxTtAxisSlope ?? '-'
      json['User inputs']['Embedment [m]'] = this.embedment ?? '-'
      json['User inputs']['Reveal window [mm]'] = this.revealWindow ?? '-'
      json['User inputs']['Maximum slope change (º)'] = this.maximumSlopeChange ?? '-'
      json['User inputs']['Typical pile size'] = this.typicalPileSize ?? '-'
      json['User inputs']['Number of strings per Full tracker'] = this.noOfStringsPerFullTracker ?? '-'
      json['User inputs']['Number of modules per Full tracker'] = this.noOfModulesPerFullTracker ?? '-'
      json['User inputs']['Number of piles (piers) per Full tracker'] = this.noOfPilesPerFullTracker ?? '-'
      json['User inputs']['Number of strings per Partial tracker'] = this.noOfStringsPerPartialTracker ?? '-'
      json['User inputs']['Number of modules per Partial tracker'] = this.noOfModulesPerPartialTracker ?? '-'
      json['User inputs']['Number of piles (piers) per Partial tracker'] = this.noOfPilesPerPartialTracker ?? '-'
      json['User inputs']['Max E-W beam slope (º)'] = this.maxEwBeamSlope ?? '-'

      //assign orientation values
      json['User inputs']['PV Module tilt min [º]'] = this.pvModuleTiltMin ?? '-'
      json['User inputs']['PV Module tilt max [º]'] = this.pvModuleTiltMax ?? '-'
      json['User inputs']['Enable backtracking'] = this.enableBacktracking ?? '-'
      json['User inputs']['Piles per table'] = this.pilesPerTable ?? '-'
      json['BoQ output']['Total grading [bcm]'] = totalGrading ?? '-'

      this.displayCompareJson["ScenarioComparison"].push(json)
      this.simDynamoOBJ = {};
      this.formatScenarioCompareData()
      if (this.displayCompareJson["ScenarioComparison"].length <= 1) {
        this.showChildrenOnCompare()
      }
      this.scenarioCount = this.displayCompareJson["ScenarioComparison"].length + 1
    }
  }

  cancelScenario(ele, id) {
    var index = 0;
    this.compareScenario.filter(x => {
      if (x[0] == ele && x[1] == id) {
        this.compareScenario.splice(index, 1);
        var checkBox = <HTMLInputElement>document.getElementById("compareScenarioValues_" + id)
        if (checkBox != null && checkBox.checked) {
          checkBox.checked = false
        }
        this.displayCompareJson["ScenarioComparison"].splice(index, 1)
        this.arcgisService.simulationComponent.scenarios.filter(x => {
          if (x.id == id) {
            x.isCompareChecked = false
          }
        })
      }
      index += 1
    })
    if (this.compareScenario.length == 0) {
      this.isShow = true
      this.isShowResult = true
    }

    if (this.displayCompareJson["ScenarioComparison"].length > 0) {
      this.formatScenarioCompareData()
    } else {
      this.displayCompareJson["ScenarioComparison"] = []
      // below set of condition updated by akshay to check the condition on deleting simulation as it is called on delete simulation
      if ('ScenarioComparisonFormattedData' in this.displayCompareJson) {
        if (Object.keys(this.displayCompareJson['ScenarioComparisonFormattedData']).length != 0) {
          //reset User inputs and Configuration details header selection collapsed after uncheck the compare button
          this.parentContainers.filter(x => {
            if (x.header == 'User inputs' || x.header == 'Configuration details') {
              x.showChildren = false
            } else {
              x.showChildren = true
            }
          })
        }
      }
    }
  }

  deleteAll() {
    this.compareScenario.filter(x => {
      if (x[0] == this.arcgisService.simulationComponent.currentSimulation.simName) {
        var checkBox = <HTMLInputElement>document.getElementById("compareScenarioValues_" + x[1])
        if (checkBox != null && checkBox.checked) {
          checkBox.checked = false
        }
      }
    })
    this.arcgisService.simulationComponent.scenarios.filter(x => {
      x.isCompareChecked = false
    })
    this.compareScenario = [];
    this.displayCompareJson["ScenarioComparison"] = [];
    this.isShow = true;

    //reset User inputs and Configuration details header selection collapsed after clear the comparison
    this.parentContainers.filter(x => {
      if (x.header == 'User inputs' || x.header == 'Configuration details') {
        x.showChildren = false
      } else {
        x.showChildren = true
      }
    })
  }


  cancelPopup() {
    this.isShowResult = true;
    this.isShow = false;
  }

  compareResult() {
    this.isShow = true;
    this.state = this.arcgisService.simulationComponent.siteInfo.attributes.Region
    this.city = this.arcgisService.simulationComponent.siteInfo.attributes.City
    this.projectName = this.arcgisService.simulationComponent.siteNameForSiteInfo
    this.location = this.arcgisService.simulationComponent.locationInfo[0] + ", " + this.arcgisService.simulationComponent.locationInfo[1]
    this.ppProjectID = this.arcgisService.simulationComponent.pp_ProjectID
    this.isShowResult = false;
  }

  generateExcel() {
    let l = this.displayCompareJson.ScenarioComparison.length;
    let header = ["Scenario ID"];
    for (let i = 0; i < l; i++) {
      let val = [this.displayCompareJson.ScenarioComparison[i].scenarios + 1];
      let simName = [this.displayCompareJson.ScenarioComparison[i].simulation_name];
      let headerName = simName + "_scenario " + val;
      header.push(headerName);
    }
    let topics = []
    topics = Object.keys(this.displayCompareJson.ScenarioComparison[0]);
    topics.splice(0, 2);

    let len = topics.length;
    let title = [];

    let data = []

    for (let i = 0; i < len; i++) {
      topics[i] = [topics[i]];
      let temp = topics[i][0];
      data.push(topics[i]);
      title = Object.keys(this.displayCompareJson.ScenarioComparison[0][temp]);
      for (let j = 0; j < title.length; j++) {
        let val = [Object.keys(this.displayCompareJson.ScenarioComparison[0][temp])[j]];
        data.push(val);
      }
    }

    let m = topics.length;
    let n = this.displayCompareJson.ScenarioComparison.length;

    let tempData = [];
    let b = data.length
    for (let l = 0; l < n; l++) {
      tempData = [];
      for (let i = 0; i < m; i++) {
        let val = Object.values(this.displayCompareJson.ScenarioComparison[l][topics[i][0]]);
        tempData.push('');
        for (let j = 0; j < val.length; j++) {
          tempData.push(val[j]);
        }
      }
      for (let d = 0; d < b; d++) {
        if (this.isSubHeaders(data[d][0])) {
          data[d].push('');
        } else {
          data[d].push(tempData[d]);
        }

      }
    }
    this.excelService.generateExcel(header, data);
  }

  isSubHeaders(key: string) {
    return this.subHeaders.includes(key) ? true : false;
  }

  isSubSubHeaders(key: string) {
    return this.subSubHeaders.includes(key) ? true : false;
  }

  toggleChildTable(parent: ParentContainer) {
    parent.showChildren = !parent.showChildren;
  }

  formatScenarioCompareData() {
    const transformedData = {
      "User inputs": {},
      "Analysis output": {},
      "BoQ output": {},
      "Configuration details": {}
    };

    this.displayCompareJson["ScenarioComparison"].forEach((item, index) => {

      this.parentContainers.filter(x => {
        // Iterate over each key-value pair in the "User inputs" object
        Object.entries(item[x.header]).forEach(([key, value]) => {
          if (!transformedData[x.header][key]) {
            transformedData[x.header][key] = [];
          }
          transformedData[x.header][key][index] = value;
        });
      })
    });

    const formattedData = {
      "User inputs": Object.entries(transformedData["User inputs"]).map(([key, value]) => Array.isArray(value) ? [key, ...value] : [key, value]),
      "Analysis output": Object.entries(transformedData["Analysis output"]).map(([key, value]) => Array.isArray(value) ? [key, ...value] : [key, value]),
      "BoQ output": Object.entries(transformedData["BoQ output"]).map(([key, value]) => Array.isArray(value) ? [key, ...value] : [key, value]),
      "Configuration details": Object.entries(transformedData["Configuration details"]).map(([key, value]) => Array.isArray(value) ? [key, ...value] : [key, value])
    };

    this.displayCompareJson["ScenarioComparisonFormattedData"] = formattedData
  }

  showChildrenOnCompare() {
    this.parentContainers.filter(x => {
      if (x.header !== 'User inputs' && x.header !== 'Configuration details') {
        x.showChildren = true
      }
    })
  }

  compareRowValues(rows, i) {
    var values = [...rows]
    if (values.length > 2 && i > 0) {
      values = values.slice(1)

      const referenceValue = values[0];
      for (let i = 1; i < values.length; i++) {
        if (values[i] != referenceValue) {
          return true; // Different value found
        }
      }
    }

    return false;
  }

  //format tracker type on compare window
  formatTrackerType(input) {
    let trackerType;
    if (input['rackingName'].includes('Custom')) {
      if (input["trackerType"] == 'genericTracker') {
        trackerType = 'Custom single-axis tracker'
      } else if (input["trackerType"] == '1PMultiStringTracker') {
        trackerType = 'Custom 1P multi-string tracker'
      } else if (input["trackerType"] == 'gft') {
        trackerType = 'Custom ground fixed tilt'
      }
    } else {
      if (input["trackerType"] == 'genericTracker') {
        trackerType = 'Single-axis tracker'
      } else if (input["trackerType"] == '1PMultiStringTracker') {
        trackerType = '1P multi-string tracker'
      } else if (input["trackerType"] == 'gft') {
        trackerType = 'Ground fixed tilt'
      }
    }

    return trackerType
  }

  //set all common field values for compare window (generic, 1p, gft)
  setCommonPropertyValues() {
    this.widthGap = this.simDynamoOBJ.inputs['productData']['module_width_gap'] ?? '-'
    this.embedment = this.simDynamoOBJ.inputs['productData']['terrainAnalysisInputs']['embedment'] ?? '-'
    this.revealWindow = this.simDynamoOBJ.inputs['productData']['terrainAnalysisInputs']['revealWindow'] ?? '-'
    this.typicalPileSize = this.simDynamoOBJ.inputs['productData']['terrainAnalysisInputs']['typicalPileSize'] ?? '-'
    this.gapBetweenRacks = this.simDynamoOBJ.inputs['interRackGap'] ?? '-'
  }

  //set common values for 1p and generic trackers
  setGenericAndGftCommonPropertyValues() {
    this.heightGap = this.simDynamoOBJ.inputs['productData']['module_height_gap'] ?? '-'
    this.pvModulesPerStringEw = this.simDynamoOBJ.inputs['productData']['modperstringEW'] ?? '-'
    this.pvModulesPerStringNs = this.simDynamoOBJ.inputs['productData']['modperstringNS'] ?? '-'
    this.noOfPvModulesPerRows = this.simDynamoOBJ.inputs['productData']['table_rows'] ?? '-'
    this.noOfPvModulesPerColumns = this.simDynamoOBJ.inputs['productData']['table_column'] ?? '-'
    this.minimumPileReveal = this.simDynamoOBJ.inputs['productData']['heightAboveGround'] ?? '-'

    if ('piles_per_table' in this.arcgisService.simulationComponent.simDynamoObj.inputs) {
      this.pilesPerTable = this.arcgisService.simulationComponent.simDynamoObj.inputs['piles_per_table']
    } else {
      this.pilesPerTable = '6'
    }
  }

  //set 1p tracker property values
  set1pTrackerPropertyValues() {
    this.pvModulesPerString = this.simDynamoOBJ.inputs['IPMultiStringDetails']['modulesPerString'] ?? '-'
    this.motorTableGap = this.simDynamoOBJ.inputs['IPMultiStringDetails']['motorTableGap'] ?? '-'
    this.gapBetweenTables = this.simDynamoOBJ.inputs['IPMultiStringDetails']['gapBetweenTables'] ?? '-'
    this.minimumPileReveal = this.simDynamoOBJ.inputs['IPMultiStringDetails']['heightAboveGroundTracker'] ?? '-'
    this.maximumSlopeChange = this.simDynamoOBJ.inputs['productData']['terrainAnalysisInputs']['maximumSlopeChange'] ?? '-'
    this.noOfStringsPerFullTracker = this.simDynamoOBJ.inputs['IPMultiStringDetails']['fullTrackers']['numOfStringsPerTracker'] ?? '-'
    this.noOfModulesPerFullTracker = this.simDynamoOBJ.inputs['IPMultiStringDetails']['fullTrackers']['modulesPerTracker'] ?? '-'
    this.noOfPilesPerFullTracker = this.simDynamoOBJ.inputs['IPMultiStringDetails']['fullTrackers']['pilesCount'] ?? '-'
    this.noOfStringsPerPartialTracker = this.simDynamoOBJ.inputs['IPMultiStringDetails']['partialTrackers']['numOfStringsPerTracker'] ?? '-'
    this.noOfModulesPerPartialTracker = this.simDynamoOBJ.inputs['IPMultiStringDetails']['partialTrackers']['modulesPerTracker'] ?? '-'
    this.noOfPilesPerPartialTracker = this.simDynamoOBJ.inputs['IPMultiStringDetails']['partialTrackers']['pilesCount'] ?? '-'
    this.enableBacktracking = this.simDynamoOBJ.inputs['productData']['useBacktracking'] ?? '-'
    this.maxTtAxisSlope = this.simDynamoOBJ.inputs['productData']['terrainAnalysisInputs']['maxTTaxisSlope'] ?? '-'
  }

  //set generic tracker property values
  setGenericTrackerPropertyValues() {
    this.maximumSlopeChange = this.simDynamoOBJ.inputs['productData']['terrainAnalysisInputs']['maximumSlopeChange'] ?? '-'
    this.pvModuleTiltMin = this.simDynamoOBJ.inputs['productData']['moduleTiltMin'] ?? '-'
    this.pvModuleTiltMax = this.simDynamoOBJ.inputs['productData']['moduleTiltMax'] ?? '-'
    this.enableBacktracking = this.simDynamoOBJ.inputs['productData']['useBacktracking'] ?? '-'
    this.maxTtAxisSlope = this.simDynamoOBJ.inputs['productData']['terrainAnalysisInputs']['maxTTaxisSlope'] ?? '-'
  }

  //set gft tracker property values
  setGftTrackerPropertyValues() {
    this.maxEwBeamSlope = this.simDynamoOBJ.inputs['productData']['terrainAnalysisInputs']['maxEWbeam'] ?? '-'
  }

  //reset compare window property values
  resetPropertyValues() {
    this.widthGap = '-'
    this.heightGap = '-'
    this.pvModulesPerStringEw = '-'
    this.pvModulesPerStringNs = '-'
    this.pvModulesPerString = '-'
    this.noOfPvModulesPerRows = '-'
    this.noOfPvModulesPerColumns = '-'
    this.motorTableGap = '-'
    this.gapBetweenTables = '-'
    this.gapBetweenRacks = '-'
    this.minimumPileReveal = '-'
    this.maxTtAxisSlope = '-'
    this.embedment = '-'
    this.revealWindow = '-'
    this.maximumSlopeChange = '-'
    this.typicalPileSize = '-'
    this.noOfStringsPerFullTracker = '-'
    this.noOfModulesPerFullTracker = '-'
    this.noOfPilesPerFullTracker = '-'
    this.noOfStringsPerPartialTracker = '-'
    this.noOfModulesPerPartialTracker = '-'
    this.noOfPilesPerPartialTracker = '-'
    this.pvModuleTiltMin = '-'
    this.pvModuleTiltMax = '-'
    this.enableBacktracking = '-'
    this.pilesPerTable = '-'
    this.maxEwBeamSlope = '-'
  }

  //add roman letters with subSubHeaders
  addRomanLetterForSubSubheaders(value) {
    let index = this.subSubHeaders.indexOf(value);

    return this.intToRoman(index + 1) + ') ' + value
  }

  //convert integer to roman letters
  intToRoman(num: number): string {
    // Define Roman numerals with values and corresponding lowercase letters
    const romanMap = [
      { value: 1000, numeral: 'm' },
      { value: 900, numeral: 'cm' },
      { value: 500, numeral: 'd' },
      { value: 400, numeral: 'cd' },
      { value: 100, numeral: 'c' },
      { value: 90, numeral: 'xc' },
      { value: 50, numeral: 'l' },
      { value: 40, numeral: 'xl' },
      { value: 10, numeral: 'x' },
      { value: 9, numeral: 'ix' },
      { value: 5, numeral: 'v' },
      { value: 4, numeral: 'iv' },
      { value: 1, numeral: 'i' },
    ];

    let result = "";
    let remaining = num;

    // Loop through Roman numeral map in descending order (largest to smallest)
    for (const { value, numeral } of romanMap) {
      // While the remaining number is greater than or equal to the current value
      while (remaining >= value) {
        result += numeral;
        remaining -= value;
      }
    }

    return result;
  }
}
