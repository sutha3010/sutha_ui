window.onload = function() {
    renderTextboxes();
}

function renderTextboxes() {
    let numOfTextboxes = 9;
    let container = document.getElementById('textboxContainer');

    for (let i = 0; i < numOfTextboxes; i++) {
        let textbox = document.createElement('input');
        textbox.type = 'text';
        textbox.placeholder = `Textbox ${i + 1}`;
        
        container.appendChild(textbox);
        container.appendChild(document.createElement('br'));
    }
}
