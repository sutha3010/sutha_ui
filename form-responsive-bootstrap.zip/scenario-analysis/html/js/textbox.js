window.onload = function() {
    const form = document.querySelector('form');
    
    for (let i = 0; i < 9; i++) {
        let div = document.createElement('div');

        let label = document.createElement('label');
        label.className = 'form-label';
        label.htmlFor = 'textbox' + i;
        label.innerText = 'TextBox ' + (i + 1);

        let input = document.createElement('input');
        input.type = 'text';
        input.name = 'textbox' + i;
        input.id = 'textbox' + i;
        input.className = 'form-control';
        input.placeholder = 'TextBox ' + (i + 1);

        div.appendChild(label);
        div.appendChild(input);

        form.appendChild(div);
    }
}
