import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { SharedService } from '../service/shared.service';
import { TerrainProInfoComponent } from '../terrain-pro-info/terrain-pro-info.component';

@Component({
  selector: 'app-top-banner',
  templateUrl: './top-banner.component.html',
  styleUrls: ['./top-banner.component.css']
})
export class TopBannerComponent implements OnInit {
  isAnalysisPage:boolean =false;
  @Input() projectName = ''
  @Input() layoutName = '';
  isReportDownload:boolean=false

  @ViewChild(TerrainProInfoComponent) TerrainProInfoComponent: TerrainProInfoComponent;

  constructor(public sharedService: SharedService) {
    this.sharedService.terrainProTopBarComponent = this
   }

  ngOnInit(): void {
  }

  downloadSolution(){
    this.sharedService.terrainproAnalysisComponent.downloadSolution()
  }

  downloadEarthWorkReport(){
    this.isReportDownload =true
    this.sharedService.terrainproAnalysisComponent.downloadEarthWorkReport()
  }

  isDownloadBtnDisabled(){
    return this.sharedService.terrainproAnalysisComponent !=undefined ? this.sharedService.terrainproAnalysisComponent.isDownloadBtnDisabled():true
  }

  isDownloadReportDisabled(){
    return this.sharedService.terrainproAnalysisComponent !=undefined ? this.sharedService.terrainproAnalysisComponent.isDownloadReportDisabled():true
  }

  openInformationPopup() {
    this.TerrainProInfoComponent.openInformationModal()
  }
}
