function showSubRibbon(subRibbonId) {
    var subRibbons = document.querySelectorAll(".sub-ribbon");
    for (var i = 0; i < subRibbons.length; i++) {
      subRibbons[i].style.display = "none";
    }
    var subRibbon = document.getElementById(subRibbonId);
    subRibbon.style.display = "flex";
  }

  