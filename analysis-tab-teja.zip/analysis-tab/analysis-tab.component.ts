import { ChangeDetectorRef, Component, ElementRef, EventEmitter, HostListener, Input, OnInit, Output, ViewChild } from '@angular/core';
import { DatePipe, formatDate } from '@angular/common';
import { TerrainProService } from '../terrain-pro.service';
import { SocketService } from 'src/app/service/socket.service';
import { SharedService } from '../service/shared.service';
import { ArcgisMapService } from 'src/app/service/arcgis-map/arcgis-map.service';
import * as JSZip from 'jszip';
import { file } from 'jszip';
import * as FileSaver from 'file-saver';
import { GraphService } from '../chart-service/graph.service';
import { SnapshotMapService } from 'src/app/service/arcgis-map/snapshot-map.service';


@Component({
  selector: 'app-analysis-tab',
  templateUrl: './analysis-tab.component.html',
  styleUrls: ['../masterCss.css','./analysis-tab.component.css'],
})
export class AnalysisTabComponent implements OnInit {


  @ViewChild('unitModal', { static: false }) unitModal: ElementRef;
  @ViewChild('listModal', { static: false }) listModal: ElementRef;
  @ViewChild('listModalContent', { static: false }) listModalContent: ElementRef;
  @ViewChild('carousel', { static: false }) carousel: ElementRef;
  @ViewChild('inputModal', { static: false }) inputModal: ElementRef;


  @Output() configurationLoaded = new EventEmitter<any>()
  @Output() triggerConfigurationLoader = new EventEmitter<any>()
  @Input() layoutId = null;
  @Input() userDetails;
  @Input() projectId = null;
  @Input() isInitialRun = false;
  @Input() isViewOnlyAccess = false;

  // below code for close input parameter window by escape btn
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key == 'Escape'){
      this.closeSelectionWindow()
    }
}

  titleMessage;
  activeBorder = false;
  unitActiveBorder = false;
  compareTable = false;
  isGFT=false;
  isMercatorConfigurations: boolean =false;
  profileViewerData:any=[];

  @HostListener('document:click', ['$event'])
  DocumentClick(event: MouseEvent) {
    const target = event.target as Element;
    if ((target.matches('path') && target.parentElement.parentElement.parentElement.className.includes('bookmark-icon')) || (target.matches('svg') && target.parentElement.className.includes('bookmark-icon'))||(target.classList.contains('cdk-overlay-backdrop') && target.parentElement.children[1].children[0].children[0].classList.contains('mat-menu-panel'))) {
      // do nothing
    }  else {
      if (!this.listModal.nativeElement.contains(event.target) && !this.carousel.nativeElement.contains(event.target)) {
        if (this.state == "open") {
          this.showConfigurationList()
        }
      }
    }

  }



  state = "closed";
  slideIndex = 1;

  //default analysislist
  selectedConfig = {
    'id': '',
    'name': '', 'inputParameters': [
      { 'title': 'Minimum pile reveal', 'value': 0, 'unit': 'm', 'active': false, 'availableValues': [] },
      { 'title': 'Maximum TT-axis slope', 'value': 0, 'unit': '°', 'active': false, 'availableValues': [] },
      { 'title': 'Reveal window', 'value': 0, 'unit': 'mm', 'active': false, 'availableValues': [] },
      { 'title': 'Maximum slope change', 'value': 0, 'unit': '°', 'active': false, 'availableValues': [] }],
    'isCompleted': false,
    'status': '',
    'earthWorkData': {},
    'alternativeTitle':''
  }
  //default input parameters
  inputParameters = [
    { 'title': 'Minimum pile reveal', 'value': 0, 'unit': 'm', 'active': false, 'availableValues': [], 'directive': 'lengthConversionDirective' ,'isDisabled':false,'alternativeTitle':'' },
    { 'title': 'Maximum TT-axis slope', 'value': 0, 'unit': '°', 'active': false, 'availableValues': [], 'directive': 'angleConversionDirective','isDisabled':false,'alternativeTitle':'' },
    { 'title': 'Reveal window', 'value': 0, 'unit': 'mm', 'active': false, 'availableValues': [], 'directive': 'lengthConversionDirective' ,'isDisabled':false,'alternativeTitle':'' },
    { 'title': 'Maximum slope change', 'value': 0, 'unit': '°', 'active': false, 'availableValues': [], 'directive': 'angleConversionDirective','isDisabled':false,'alternativeTitle':'' }]


  //unit options
  units = {
    'length': ['SI', 'Imperial'],
    'angle': ['Degree', 'Percentage']
  }

  layoutInfoTemplate=[
    { 'title': 'Name', 'value': '', 'name': 'projectName', 'isString':true,'class':"layout-data" },
    { 'title': 'Layout', 'value': '', 'name': 'layoutName', 'isString':true,'class':"layout-data" },
    { 'title': 'Location', 'value': '', 'name': 'location', 'isString':true,'class':"layout-data" },
    { 'title': 'Boundary(ha)', 'value': '', 'name': 'boundaryArea', 'isString':false,'class':"layout-data" },
    { 'title': 'DC (MW)', 'value': '', 'name': 'dc', 'isString':false,'class':"layout-data layout-data-hide"},
    { 'title': 'AC (MW)', 'value': '', 'name': 'ac', 'isString':false,'class':"layout-data layout-data-hide" },
    { 'title': 'DC/AC ', 'value': '', 'name': 'dc/ac', 'isString':false ,'class':"layout-data layout-data-hide"},
    { 'title': 'GCR', 'value': '', 'name': 'gcr', 'isString':false ,'class':"layout-data layout-data-hide"},
    { 'title': 'Row spacing (m)', 'value': '', 'name': 'rowSpacing', 'isString':false ,'class':"layout-data layout-data-hide"},
    { 'title': 'Racking', 'value': '', 'name': 'racking', 'isString':true ,'class':"layout-data layout-data-hide"},
    { 'title': 'Number of racks', 'value': '', 'name': 'noOfRacks', 'isString':false,'class':"layout-data layout-data-hide"},
    { 'title': 'Module manufacturer', 'value': '', 'name': 'moduleManufacturer', 'isString':true ,'class':"layout-data layout-data-hide"},
    { 'title': 'Module SKU', 'value': '', 'name': 'moduleSku', 'isString':true,'class':"layout-data layout-data-hide"},
    { 'title': 'Module rating (W)', 'value': '', 'name': 'moduleRating', 'isString':false,'class':"layout-data layout-data-hide"},
    { 'title': 'Number of modules', 'value': '', 'name': 'noOfoModules', 'isString':false,'class':"layout-data layout-data-hide"},
    { 'title': 'Inverter manufacturer', 'value': '', 'name': 'inverterManufacturer', 'isString':true,'class':"layout-data layout-data-hide"},
    { 'title': 'Inverter model', 'value': '', 'name': 'inverterModel', 'isString':true ,'class':"layout-data layout-data-hide"},
    { 'title': 'Inverter rating (MW)', 'value': '', 'name': 'inverterrating', 'isString':false,'class':"layout-data layout-data-hide"},
    { 'title': 'Number of inverters', 'value': '', 'name': 'noOfInverters', 'isString':false,'class':"layout-data layout-data-hide"},
  ]


  selectedUnit: any;
  sourceUnit:any;
  defaultUnit: any = { 'length': 'SI', 'angle': 'Degree', 'isDefaultUpdated': false };
  isDefaultUnit: boolean = false;
  //input related variables
  inputSelectionObject: any;
  showInputSelectionModal: boolean = false;

  //configuration data variables
  defaultAnalysisList: any[] = []
  isLayoutInfoTabOpen: boolean = false;
  configurationList: any[] = [];
  layoutInfo: any;

  //list view variables
  configTableData: any[] = [];
  compareConfigurationList: any[] = [];

  //compare modal variables
  showCompareModal: boolean = false;

  solutionData: any[] = []
  selectedSolution: any;
  defaultRevealWindowValues =[300,450,600]
  isNavigationTriggered = false;

  constructor(private _cdr: ChangeDetectorRef, private service: TerrainProService, private socketService: SocketService, private sharedService: SharedService, private arcgisService: ArcgisMapService, private graphService: GraphService, private snapShotService: SnapshotMapService) {
    this.sharedService.terrainproAnalysisComponent = this;
  }

  ngOnInit(): void {
    this.selectedUnit = { 'length': 'SI', 'angle': 'Degree', 'isDefaultUpdated': false }
    this.getConfigurationsList()
    this.socketService.awsSocketInit(String(this.projectId) + '_' + String(this.layoutId));
  }


  ngAfterViewInit() {
    this.showSlides(0)
    this.showLayoutInfo(this.isLayoutInfoTabOpen);
  }




  /*** Below set of code is related to 
      forming configuration data from api */


  /** get configurtion list */
  getConfigurationsList() {
      // if layout id is available, get configurations under the layout
      this.service.getTerrainProConfigurations(this.projectId, this.layoutId).then(res => {
        this.defaultAnalysisList = res;
        this.isMercatorConfigurations = res.source =='mercator'? true: false;
        this.sharedService.terrainProRightSideMenuBarComponent.isMercatorConfiguration = this.isMercatorConfigurations;
        this.layoutInfo = res.layoutInfo;
        if(!this.isMercatorConfigurations){
          let splitContent = this.layoutInfo['projectName'].split('%20')
          this.layoutInfo['projectName'] = splitContent.join(' ')  
          let layoutName = this.layoutInfo['layoutName'].split('%20')
          this.layoutInfo['layoutName'] = layoutName.join(' ')              
          this.layoutInfo['boundaryArea']=Math.trunc((this.layoutInfo['boundaryArea']/2.471)*Math.pow(10, 1))/Math.pow(10, 1)//truncating with one decimal //acre to ha conversion
          this.layoutInfo['rowSpacing']=Math.trunc(this.layoutInfo['rowSpacing']*Math.pow(10, 1))/Math.pow(10, 1)//truncating with one decimal
          this.formLayoutInfo( res.layoutInfo)
          this.layoutInfo['latitude'] = this.defaultAnalysisList['lat'];
          this.layoutInfo['longitude'] = this.defaultAnalysisList['long'];
          this.layoutInfo['x'] = 'x' in this.layoutInfo ? this.layoutInfo['x'].toFixed(4):'-';
          this.layoutInfo['y'] = 'y' in this.layoutInfo ?this.layoutInfo['y'].toFixed(4):'-';
          this.layoutInfo['wkid'] = 'wkid' in this.layoutInfo ?this.layoutInfo['wkid']:'-';
          this.sharedService.terrainProHomePageComponent.layoutInfo = this.layoutInfo;
          this.sharedService.terrainProHomePageComponent.formDataSetInfo()
          this.isGFT = this.layoutInfo['racking'] == 'Ground fixed tilt' || this.layoutInfo['racking'] == 'Custom Stationary Fixed Tilt (Ground)'? true:false;
         
        } else{
          this.layoutInfo['racking'] = 'Single axis tracker';
          this.isGFT = this.layoutInfo['racking'] == 'Ground fixed tilt' || this.layoutInfo['racking'] == 'Custom Stationary Fixed Tilt (Ground)'? true:false;
          this.layoutInfo['projectName'] =res.projectName;
          this.layoutInfo['layoutName'] =this.layoutInfo['layoutName'];
        }
       this.selectedUnit = res.unitSelection;
       this.sourceUnit = res.sourceUnit;
        this.defaultAnalysisList['configurations'].filter(config => {
          if ('isUpdatedVersion' in config.earthWorkData && config.earthWorkData['isUpdatedVersion']){
            config['updatedEarthWorkData']= this.updateUnitInEarthworkData(config.earthWorkData, this.sourceUnit, this.selectedUnit)
          }else{
            config['updatedEarthWorkData']= this.updateUnitConversionInEarthworkData(config.earthWorkData)
          }
        })
        
        this.formConfigList();
        this.formConfigTableData();
        this.setDefaultRevealWindowConfiguration()
        this.updateUnitConvertionInData();    
        this.updateEarthworkDataInGraph()
        //Load initalize map 
        const container = this.sharedService.terrainProHomePageComponent.mapViewEl?.nativeElement;
        this.arcgisService.getTerrainProArcgisToken(container)
      },error=>{
        this.configurationLoaded.emit()
      })
    

  }

  setDefaultRevealWindowConfiguration(){
    var defaultRevealWindowVal = this.defaultRevealWindowValues[Math.floor(this.defaultRevealWindowValues.length / 2)];
    let config = this.defaultAnalysisList['configurations'].filter(config =>config['revealWindow']*1000 == defaultRevealWindowVal && config['status']  == 'Completed')
    //check if default revealwindow value available in configuration list
    if(config.length != 0){
      //load the default configuration based on default reveal window
      let idx = this.configurationList.findIndex(con=>con.id ===config[0].id)
      this.slideIndex = idx + 1;
      this._cdr.detectChanges()
      this.showSlides( this.slideIndex)    
    }else{
      //load the default configuration with min reveal window
      let list = this.defaultAnalysisList['configurations'].filter(config=> config['status'] == 'Completed')
      let configWithMinRevealWindow = list.sort((a, b) => a['revealWindow'] - b['revealWindow'])
      let idx = this.configurationList.findIndex(con=>con.id ===configWithMinRevealWindow[0].id )
      this.slideIndex = idx + 1;
      this._cdr.detectChanges()
      this.showSlides( this.slideIndex)    
    }
    // check if selected configuration is completed, then call get solution to load data in map and profile viewer
    if(this.selectedConfig['isCompleted']){
      this.getSolution(this.defaultAnalysisList['projectId'], this.defaultAnalysisList['layoutId'], this.selectedConfig['id'],true)
      this.updateEarthworkDataInGraph()
    }

  }

  /** Forming json data to show in the UI */
  formConfigList() {
    let list = []
    let revealWindowAvailableValues = this.defaultAnalysisList['availableValues']['revealWindow'] != undefined ?this.sourceUnit == 'SI'? this.defaultAnalysisList['availableValues']['revealWindow'].map(x => x * 1000):this.defaultAnalysisList['availableValues']['revealWindow'].map(x => x * 12) : []
    this.defaultAnalysisList['configurations'].filter(config => {
      let inputs = JSON.parse(JSON.stringify(this.inputParameters))
      // mapping input values
      inputs.filter(item => {
        if (item.title == 'Minimum pile reveal') {
          item.value = config['minPileReveal']
          item.availableValues = this.defaultAnalysisList['availableValues']['minPileReveal'] != undefined ? this.defaultAnalysisList['availableValues']['minPileReveal'] : []
          item.unit = this.sourceUnit =='SI'?'m':'ft'
        } else if (item.title == 'Maximum TT-axis slope') {
          item.value = config['maxTTAxisSlope']
          item.availableValues = this.defaultAnalysisList['availableValues']['maxTTAxisSlope'] != undefined ? this.defaultAnalysisList['availableValues']['maxTTAxisSlope'] : []
          if(this.layoutInfo['racking'] == 'Ground fixed tilt' || this.layoutInfo['racking'] == 'Custom Stationary Fixed Tilt (Ground)'){
            item.alternativeTitle = 'Max E-W beam slope'
          }
        } else if (item.title == 'Reveal window') {
          item.value = this.sourceUnit == 'SI'?config['revealWindow'] * 1000:config['revealWindow']*12
          item.availableValues = this.defaultAnalysisList['availableValues']['revealWindow'] != undefined ? revealWindowAvailableValues : []
          item.unit = this.sourceUnit =='SI'?'mm':'in'
        } else if (item.title == 'Maximum slope change') {
          item.value = config['maxSlopeChange']
          item.availableValues = this.defaultAnalysisList['availableValues']['maxSlopeChange'] != undefined ? this.defaultAnalysisList['availableValues']['maxSlopeChange'] : []
          
          if(this.layoutInfo['racking'] == 'Ground fixed tilt' || this.layoutInfo['racking'] == 'Custom Stationary Fixed Tilt (Ground)'){
            item.isDisabled =true;
          }
        }
      })

      list.push({
        'id': config.id,
        'name': config.configurationName,
        'inputParameters': inputs,
        'isCompleted': config.isCompleted,
        'status': config.status,
        'defaultEarthWorkData': config.earthWorkData,
        'earthWorkData':config.updatedEarthWorkData,
        'ownerName': config.ownerName['firstName'] + " " + config.ownerName['lastName'],
        'sortingSequence':config.sortingSequence
      })

    })
    this.configurationList = list
    //check if there is value for order field in configuration
    let isSortingSequenceAvailable = this.configurationList.filter(x=>x.sortingSequence !=0)
    if (isSortingSequenceAvailable.length !=0){
      //sort by order
      this.configurationList.sort((a, b) => a.sortingSequence - b.sortingSequence);
    }else{
     //initialize and update order
      this.configurationList = this.initializeSortingSequence(list,true)
    }
    this.configurationList = [...new Map(this.configurationList.map(item => [item['id'], item])).values()]
    this.configurationList = [...this.configurationList]
    this.slideIndex = 1;
    this._cdr.detectChanges()
    this.showSlides(1)    
    this.updateEarthworkDataInGraph()
  }


  /** forming configuration table data */
  formConfigTableData() {
    let list = []
    this.defaultAnalysisList['configurations'].filter(config => {

      list.push({
        'id': config.id,
        'name': config.configurationName,
        'minPileReveal': config['minPileReveal'],
        'maxTTAxisSlope': config['maxTTAxisSlope'],
        'revealWindow': this.sourceUnit == 'SI' ?config['revealWindow'] * 1000: config['revealWindow'] *12,
        'maxSlopeChange': config['maxSlopeChange'],
        'isBookmarked': config['isBookMarked'],
        'isCompleted': config.isCompleted,
        'isCompareChecked': false,
        'status': config.status,
        'defaultEarthWorkData': config.earthWorkData,
        'earthWorkData':config.updatedEarthWorkData,
        'unit': this.sourceUnit == 'SI'? JSON.parse(JSON.stringify({ 'length': 'SI', 'angle': 'Degree', 'isDefaultUpdated': false })):JSON.parse(JSON.stringify({ 'length': 'Imperial', 'angle': 'Degree', 'isDefaultUpdated': false })),
        'sortingSequence':config.sortingSequence,
        'isActive':false
      })

    })
    this.configTableData = list
    let isSortingSequenceAvailable = this.configTableData.filter(x=>x.sortingSequence !=0)
    if (isSortingSequenceAvailable.length !=0){
      //sort by sortingSequence
      this.configTableData.sort((a, b) => a.sortingSequence - b.sortingSequence);
    }else{
     //initialize and update order
      this.configTableData = this.initializeSortingSequence(list,false)
    }
    this.configTableData = [...new Map(this.configTableData.map(item => [item['id'], item])).values()]
    this.configTableData = [...this.configTableData]   
  }

  formLayoutInfo(data){
this.layoutInfoTemplate.filter(layoutData=>
  layoutData.value = data[layoutData.name] )

  }

  /** navigation carousel related code  -START
   * navigation using slides
   * 
  */


  //slide operation
  plusSlides(n) {
    this.isNavigationTriggered = true;
    this.showSlides((this.slideIndex += n)); 
    // adding delay to allow user to navigate to the desired configuration without loading the solution of intermediate configuration   
    setTimeout(()=>{      
    if(!this.isNavigationTriggered){
      this.getSolution(this.defaultAnalysisList['projectId'], this.defaultAnalysisList['layoutId'], this.selectedConfig['id'],true)
      this.updateEarthworkDataInGraph()
      }
    },2000)
  }

  /** loading analysis on slide */
  showSlides(n) {
    let i;
    let slides = document.getElementsByClassName('configSlides');
    if (n > slides.length) {
      this.slideIndex = 1;
    }
    if (n < 1) {
      this.slideIndex = slides.length;
    }

    //hiding all the slides
    for (i = 0; i < slides.length; i++) {
      slides[i]['style'].display = 'none';
    }

    // display the selected configuration slide
    if (slides.length != 0) {
      this.selectedConfig = { 'id': '', 'name': '', 'inputParameters': this.inputParameters, 'isCompleted': false, 'status': '', 'earthWorkData': {} ,'alternativeTitle':''}
      slides[this.slideIndex - 1]['style'].display = 'block';

      //update the selected analysis parameters
      this.selectedConfig = this.configurationList[this.slideIndex - 1]

      //update config status in result tab      
      this.sharedService.resultTabComponent.isConfigurationCompleted =  this.selectedConfig['status'] == 'Completed'? true: false;
      this.sharedService.resultTabComponent.isConfigurationInProgress =  this.selectedConfig['status'] == 'Inprogress'? true: false;
      this.sharedService.resultTabComponent.isConfigurationFailed =  this.selectedConfig['status'] == 'Failed'? true: false;

      //update active state of configurations
      this.configTableData.filter(x=>{
          x.isActive =x.id ==this.selectedConfig.id? true:false;
      })
      this._cdr.detectChanges()
      //update highlight in configuration list table 
      if(this.sharedService.configTableComponent !=undefined){
        this.sharedService.configTableComponent.selectedRowIndex = this.selectedConfig.id;
      }

    }
    this.isNavigationTriggered =false;
  }

  isChevronDisabled(isLeftChecvron) {
    if (isLeftChecvron) {
      return this.slideIndex - 1 == 0
    } else {
      return this.slideIndex == this.configurationList.length
    }
  }

  // load the selected configuration data in UI on selection from list view
  loadSelectedConfiguration(id) {
    if (this.selectedConfig.id != id) {

      // get index of selected configuration , and load that configuration in left side navigation view   
      let index = this.configurationList.findIndex(row => row.id == id)
      this.slideIndex = index + 1;
      this.showSlides(this.slideIndex)

      //get solution of selected config and update earthwork data respectively
      this.getSolution(this.defaultAnalysisList['projectId'], this.defaultAnalysisList['layoutId'], this.selectedConfig['id'], true)
      this.updateEarthworkDataInGraph()

      // close the list view
      this.showConfigurationList()
    }
  }


  /** navigation carousel related code - END */



  /** unit selected related code -START */

  /** unit change modal */
  openUnitModal() {
    // display unit modal 
    this.unitActiveBorder = true;
    this.unitModal.nativeElement.style.display = 'block';
  }

  closeUnitModal() {
    // hide unit modal
    this.unitActiveBorder = false;
    this.unitModal.nativeElement.style.display = 'none';
  }

  // update unit change 
  updateUnitChange(isConfigurationChange=false) { 
    this.updateUnitConvertionInData();    
    this.updateEarthworkDataInGraph()
    this.sharedService.configTableComponent.updateUnit();
     //updating graph related data
     this.graphService.minimumPilereveal = this.selectedConfig.inputParameters[0]['value'];
     if(this.selectedUnit.length == 'SI'){
      this.graphService.maximumPileHeight =this.selectedConfig.inputParameters[0]['value']+ (this.selectedConfig.inputParameters[2]['value'] / 1000);
     }else{
      this.graphService.maximumPileHeight =this.selectedConfig.inputParameters[0]['value']+ (this.selectedConfig.inputParameters[2]['value'] *0.0833);
     }
     
    this.updateUnitInSolution(isConfigurationChange);
    // load unit updated data in map    
    this.arcgisService.pileAnaylsisStarted = false
    this.loadDataInMap()
    this._cdr.detectChanges();


    //hide unit modal 
    if (this.unitModal.nativeElement.style.display == 'block') {
      let request = {
        'selectedUnit': {
          'length': this.selectedUnit.length,
          'angle': this.selectedUnit.angle,
          'isDefaultUpdated': this.isDefaultUnit
        }
      }

      //update in database
      this.service.updateUnitSelection(this.defaultAnalysisList['projectId'], this.defaultAnalysisList['layoutId'], this.selectedConfig['id'], request).then(res => { })
      this.closeUnitModal();
    }
  }


  //update unit change in table data
  updateUnitConvertionInData() {
    //updating unit conversion in list view table data
    this.configTableData.filter(config => {
      if (JSON.stringify(config.unit) != JSON.stringify(this.selectedUnit)) {
        if (config.unit.length != this.selectedUnit.length) {
          //updating minpile reveal and reveal window value
          config['minPileReveal'] = this.updateLength(config.unit.length, config['minPileReveal'], 'minPileReveal')
          config['revealWindow'] = this.updateLength(config.unit.length, config['revealWindow'], 'revealWindow')
          config['unit']['length'] = JSON.parse(JSON.stringify(this.selectedUnit.length))
          config['unit']['isDefaultUpdated'] =  JSON.parse(JSON.stringify(this.selectedUnit['isDefaultUpdated']))
        }
        if (config.unit.angle != this.selectedUnit.angle) {
          //updating ttaxis and slope change values
          config['maxTTAxisSlope'] = this.updateAngle(config.unit.angle, config['maxTTAxisSlope']),
            config['maxSlopeChange'] = this.updateAngle(config.unit.angle, config['maxSlopeChange'])
          config['unit']['angle'] = JSON.parse(JSON.stringify(this.selectedUnit.angle))
          config['unit']['isDefaultUpdated'] =  JSON.parse(JSON.stringify(this.selectedUnit['isDefaultUpdated']))
        }

        if ('isUpdatedVersion' in config.defaultEarthWorkData && config.defaultEarthWorkData['isUpdatedVersion']){
          config.earthWorkData= this.updateUnitInEarthworkData(config.defaultEarthWorkData, this.sourceUnit, this.selectedUnit)
        }else{
          config.earthWorkData= this.updateUnitConversionInEarthworkData(config.defaultEarthWorkData)
        }
        // //update earthworkdata
        // config.earthWorkData = this.updateUnitConversionInEarthworkData(config.defaultEarthWorkData)
      }
    })

    let minPileRevealUnit = this.selectedUnit.length == 'SI' ? 'm' : 'ft';
    let revealWindowUnit = this.selectedUnit.length == 'SI' ? 'mm' : 'in';
    let angleUnit = this.selectedUnit.angle == 'Degree' ? '°' : '%';

    //updating unit in configuration list
    this.configurationList.filter(config => {
      config.inputParameters.filter(input => {

        if (input.title == 'Minimum pile reveal') {
          if (input.unit != minPileRevealUnit) {
            input.value = this.updateLength(input.unit, input.value, input.title)
            input.availableValues = input.availableValues.map(x => this.updateLength(input.unit, x, input.title))
            input.unit = JSON.parse(JSON.stringify(this.selectedUnit.length)) == 'SI' ? 'm' : 'ft'
          }
        } else if (input.title == 'Reveal window') {
          if (input.unit != revealWindowUnit) {
            input.value = this.updateLength(input.unit, input.value, input.title)
            input.availableValues = input.availableValues.map(x => this.updateLength(input.unit, x, input.title))
            input.unit = JSON.parse(JSON.stringify(this.selectedUnit.length)) == 'SI' ? 'mm' : 'in'

          }
        } else {
          if (input.unit != angleUnit) {
            input.value = this.updateAngle(input.unit, input.value)
            input.availableValues = input.availableValues.map(x => this.updateAngle(input.unit, x))
            input.unit = JSON.parse(JSON.stringify(this.selectedUnit.angle)) == 'Degree' ? '°' : '%'
          }
        }

      })
      if ('isUpdatedVersion' in config.defaultEarthWorkData && config.defaultEarthWorkData['isUpdatedVersion']) {
        config.earthWorkData= this.updateUnitInEarthworkData(config.defaultEarthWorkData, this.sourceUnit, this.selectedUnit)
      }else{
        config.earthWorkData= this.updateUnitConversionInEarthworkData(config.defaultEarthWorkData)
      }

      //update earthworkdata
      // config.earthWorkData = this.updateUnitConversionInEarthworkData(config.defaultEarthWorkData)
    })


    this._cdr.detectChanges()
  }


  //update unit conversion in solution
  updateUnitInSolution(isConfigurationChange=false) {
    let selectedLength = this.selectedUnit.length == 'SI' ? 'm' : 'ft';
    this.updateUnitInProfileViewer(isConfigurationChange)
    this.selectedSolution['solution'].filter(tracker => {
      tracker.piles.filter(pile => {
        if (pile['Solution']['unit'] != selectedLength) {
          pile['Position_utm']['Easting'] =  this.updateLength(pile['Solution']['unit'],   pile['Position_utm']['Easting'], 'solution')
          pile['Position_utm']['Northing'] =  this.updateLength(pile['Solution']['unit'],   pile['Position_utm']['Northing'], 'solution')
          pile['Elevation'] = this.updateLength(pile['Solution']['unit'], pile['Elevation'], 'solution')
          pile['Solution']['Top'] = this.updateLength(pile['Solution']['unit'], pile['Solution']['Top'], 'solution')
          pile['Solution']['Bottom'] = this.updateLength(pile['Solution']['unit'], pile['Solution']['Bottom'], 'solution')
          pile['Solution']['PileHeight'] = this.updateLength(pile['Solution']['unit'], pile['Solution']['PileHeight'], 'solution')
          pile['Solution']['unit'] = selectedLength;
        }
      })
    })

  }


  //update unit in profile viewer data
  updateUnitInProfileViewer(isConfigurationChange=false,solution?){
    let selectedLength = this.selectedUnit.length == 'SI' ? 'm' : 'ft';
    if(Object.keys( this.profileViewerData).length == 0){
      this.profileViewerData =JSON.parse(JSON.stringify(solution))
    }
      
    this.profileViewerData['solution'].filter(tracker => {
      tracker.piles.filter(pile => {
        if (pile['Solution']['unit'] != selectedLength) {
          pile['Position_utm']['Easting'] =  this.updateLength(pile['Solution']['unit'],   pile['Position_utm']['Easting'], 'solution')
          pile['Position_utm']['Northing'] =  this.updateLength(pile['Solution']['unit'],   pile['Position_utm']['Northing'], 'solution')
          pile['Elevation'] = this.updateLength(pile['Solution']['unit'], pile['Elevation'], 'solution')
          pile['Solution']['Top'] = this.updateLength(pile['Solution']['unit'], pile['Solution']['Top'], 'solution')
          pile['Solution']['Bottom'] = this.updateLength(pile['Solution']['unit'], pile['Solution']['Bottom'], 'solution')
          pile['Solution']['PileHeight'] = this.updateLength(pile['Solution']['unit'], pile['Solution']['PileHeight'], 'solution')
          pile['Solution']['unit'] = selectedLength;
        }
      })
    })
    this.profileViewerData['solution'] = [...this.profileViewerData['solution']]
    this.graphService.createTrackerLayoutArray(isConfigurationChange);
    return this.profileViewerData;

  }


  //unit conversion of length
  updateLength(fromUnit, value, title) {
    if (title == 'minPileReveal' || title == 'Minimum pile reveal' || title == 'solution') {
      const convertedValue = fromUnit == 'SI' || fromUnit == 'm' ? value * 3.28084 : value / 3.28084;
      return convertedValue;
    } else {
      const convertedValue = fromUnit == 'SI' || fromUnit == 'mm' ? value * 0.0393701 : value / 0.0393701;
      return convertedValue;
    }
  }


  //unit conversion of angle
  updateAngle(fromUnit, value) {
    const convertedValue = fromUnit == 'Degree' || fromUnit == '°' ? Math.tan(value*(Math.PI/180))*100 : Math.atan(value/100)*(180/Math.PI);
    return convertedValue;
  }


  //update unit in earthWorkData
  updateUnitConversionInEarthworkData(earthWork){
    let earthWorkData={};
    //update area value from meter to selected unit
if(Object.keys(earthWork).length != 0 ){
  earthWorkData['volume']={};
  earthWorkData['area']={};
  earthWorkData['depth']={};
  Object.keys(earthWork['volume']).filter(key=>{
      earthWorkData['volume'][key] =key != 'cutFillRatio'? this.selectedUnit.length == 'SI'? earthWork['volume'][key]:earthWork['volume'][key] * 1.30795:earthWork['volume'][key];
    })

    Object.keys(earthWork['area']).filter(key =>{
      if(key != 'disturbedPercent'){
      earthWorkData['area'][key] = this.selectedUnit.length == 'SI'? earthWork['area'][key] :earthWork['area'][key]*2.471 ;
      }else{
        earthWorkData['area'][key]=earthWork['area'][key]
      }
    })

    Object.keys(earthWork['depth']).filter(key =>{
      earthWorkData['depth'][key] = this.selectedUnit.length == 'SI'? earthWork['depth'][key]:earthWork['depth'][key]*3.28084;

    })
}
    
      return earthWorkData
  }


  updateUnitInEarthworkData(earthWork, sourceUnit,selectedUnit){
    let earthWorkData={};
    if (Object.keys(earthWork).length != 0) {
      //update area value from meter to selected unit
        earthWorkData['volume'] = {};
        earthWorkData['area'] = {};
        earthWorkData['depth'] = {};
    if (sourceUnit == 'Imperial'){
      if (selectedUnit.length == 'Imperial'){
          // cubic feet to cubic yard
          Object.keys(earthWork['volume']).filter(key => {
            earthWorkData['volume'][key] = key != 'cutFillRatio' ? earthWork['volume'][key] * 0.037037 : earthWork['volume'][key];
          })
          //cubic feet to acre
          Object.keys(earthWork['area']).filter(key => {
            if (key != 'disturbedPercent') {
              earthWorkData['area'][key] = earthWork['area'][key] * 0.000022956840904921;
            } else {
              earthWorkData['area'][key] = earthWork['area'][key]
            }
          })

          Object.keys(earthWork['depth']).filter(key => {
            earthWorkData['depth'][key] = earthWork['depth'][key];

          })
        

      } else{
         // if selected unit is SI (m)
          //cubic feet to cubic meter
          Object.keys(earthWork['volume']).filter(key => {
            earthWorkData['volume'][key] = key != 'cutFillRatio' ? earthWork['volume'][key] / 35.315: earthWork['volume'][key];
          })
          // cubic feet to ha
          Object.keys(earthWork['area']).filter(key => {
            if (key != 'disturbedPercent') {
              earthWorkData['area'][key] = earthWork['area'][key] /107600;
            } else {
              earthWorkData['area'][key] = earthWork['area'][key]
            }
          })
          // feet to m
          Object.keys(earthWork['depth']).filter(key => {
            earthWorkData['depth'][key] = earthWork['depth'][key]/3.281;
          })        
      }

    }else{
      if (selectedUnit.length== 'Imperial'){  

          // cubic meter to cubic yard
          Object.keys(earthWork['volume']).filter(key => {
            earthWorkData['volume'][key] = key != 'cutFillRatio' ? earthWork['volume'][key] *1.308: earthWork['volume'][key];
          })
          //cubic meter to acre
          Object.keys(earthWork['area']).filter(key => {
            if (key != 'disturbedPercent') {
              earthWorkData['area'][key] = earthWork['area'][key] /4047

            } else {
              earthWorkData['area'][key] = earthWork['area'][key]
            }
          })
          // meter to ft
          Object.keys(earthWork['depth']).filter(key => {
            earthWorkData['depth'][key] = earthWork['depth'][key]*3.28084;

          })
        

      } else{
         // if selected unit is SI (m)
          // cubic meter
          Object.keys(earthWork['volume']).filter(key => {
            earthWorkData['volume'][key] =  earthWork['volume'][key];
          })
          // cubic meter to ha
          Object.keys(earthWork['area']).filter(key => {
            if (key != 'disturbedPercent') {
              earthWorkData['area'][key] = earthWork['area'][key]/10000;
            } else {
              earthWorkData['area'][key] = earthWork['area'][key]
            }
          })
          //  m
          Object.keys(earthWork['depth']).filter(key => {
            earthWorkData['depth'][key] = earthWork['depth'][key];
          })        
      }


    }
  }
  return earthWorkData

  }


  /** unit change modal -END*/





  /*** style and animation related code -START 
   * 
   * open and close functionality of analysis list view
   * expand and close functionality of layout information in left side menu
  */




  /** show or hide analysis list */
  showConfigurationList() {
    // animation added while open and closing the list view 
    if (this.state == "closed") {
      this.compareTable = false;
      this.listModal.nativeElement.style.transition = '0.1s ease';
      this.listModal.nativeElement.style.width = '45%';
      this.listModalContent.nativeElement.style.display = 'block';
      this.state = "open";
    } else {
      this.compareTable = true;
      this.listModal.nativeElement.style.transition = '0.2s ease';
      this.listModal.nativeElement.style.width = '10%';
      this.listModal.nativeElement.style.width = '0%';
      setTimeout(() => {
        this.listModalContent.nativeElement.style.display = 'none';
        this.state = "closed";
      }, 200)
    }
  }



  /**open and close layout info */
  openLayoutInfo() {
    let tab = document.getElementById('layout');
    let elements = document.querySelectorAll('.layout-data-hide')

    if (this.isLayoutInfoTabOpen) {
      this.showLayoutInfo(!this.isLayoutInfoTabOpen);
    } else {
      this.showLayoutInfo(!this.isLayoutInfoTabOpen);
    }
    tab.style.transition = "0.6s ease";
    this.isLayoutInfoTabOpen = this.isLayoutInfoTabOpen ? false : true;
  }


  showLayoutInfo(isOpen) {
    let display = isOpen ? 'block' : 'none';
    let overflow = isOpen ? 'auto' : 'hidden';
    // let height = isOpen ? '230px' : '20%';
    let height = isOpen ? '40vh' : '21vh';
    let position = isOpen ?'relative':'absolute';
    let width ='100%';
    let margin = isOpen? '0px':'70px 0px 0px 0px';

    document.querySelectorAll('.layout-data-hide').forEach(element => {
      element['style'].display = display;
    })
    document.querySelectorAll('.layout-info').forEach(element => {
      element['style'].overflow = overflow;
      element['style'].height = height;
      element['style'].position = position;
      element['style'].width =width
      // element['style'].margin =margin
    })
  }

  //updating icon color based on the status of configuration
  getColorBasedOnstatus(ConfigStatus) {
    let color = ConfigStatus == 'Inprogress' ? '#F7D060' : ConfigStatus == 'Not submitted' ? '#808080' : ConfigStatus == 'Completed' ? '#00b300' : '#e60000';
    return color
  }

  isSelectedConfigIsInProgress(){
    let res = this.selectedConfig['status'] == 'Inprogress'? true:false;
    return res
  }



  /** style and animation related code -END */






  /** Configuartion related code - START
   * 
   *  this section of code covers below functionalities
   * Create, run configuration
   * rename configuration
   * delete configuration
   * bookmark configuration
   * 
   */




  /**creating new configuration */
  createNewConfiguration(config, availableVal) {
    let request = {
      'terrainProLayoutId': this.defaultAnalysisList['layoutId'],
      'configurationName': this.createConfigName(),
      // 'minPileReveal': this.selectedUnit.length == 'SI' ? config['inputParameters'][0].value : Number((this.updateLength(this.selectedUnit.length, config['inputParameters'][0].value, 'minPileReveal')).toFixed(4)),
      'maxTTAxisSlope': this.selectedUnit.angle == 'Degree' ? config['inputParameters'][1].value : this.updateAngle(this.selectedUnit.angle, config['inputParameters'][1].value),
      // 'revealWindow': this.selectedUnit.length == 'SI' ? config['inputParameters'][2].value > 0 ? config['inputParameters'][2].value / 1000 : config['inputParameters'][2].value : Number(this.getRevealWindowValue(config['inputParameters'][2].value).toFixed(4)),
      'maxSlopeChange': this.selectedUnit.angle == 'Degree' ? config['inputParameters'][3].value : this.updateAngle(this.selectedUnit.angle, config['inputParameters'][3].value),
      'availableValues': availableVal,
      'projectId': this.defaultAnalysisList['projectId'],
      'sortingSequence':this.configurationList.length +1
    }

    if (this.sourceUnit == 'SI') {

      //if input data is in m format
      request['minPileReveal'] = this.selectedUnit.length == 'SI' ? config['inputParameters'][0].value : Number((this.updateLength(this.selectedUnit.length, config['inputParameters'][0].value, 'minPileReveal')).toFixed(4));
      request['revealWindow'] = this.selectedUnit.length == 'SI' ? config['inputParameters'][2].value > 0 ? config['inputParameters'][2].value / 1000 : config['inputParameters'][2].value : Number(this.getRevealWindowValue(config['inputParameters'][2].value).toFixed(4));
    } else {

      //if input data is in ft format
      request['minPileReveal'] = this.selectedUnit.length == 'SI' ?  Number((config['inputParameters'][0].value * 3.281).toFixed(2)) : config['inputParameters'][0].value;
      request['revealWindow'] = config['inputParameters'][2].value > 0 ? this.selectedUnit.length == 'SI' ? Number( (config['inputParameters'][2].value / 304.8).toFixed(4)) :Number( (config['inputParameters'][2].value / 12).toFixed(4)) : config['inputParameters'][2].value;
    }

    this.triggerConfigurationLoader.emit({ 'isShowLoader': true, 'msg': "Creating configuration" })
    // creating configuration using api
    this.service.createTerrainProConfiguration(request).then(res => {
      this.triggerConfigurationLoader.emit({ 'isShowLoader': false, 'msg': "Creating configuration" })

      //adding newly created configuration in the list 
      this.configurationList.push({
        'id': res,
        'name': request.configurationName,
        'inputParameters': config['inputParameters'],
        'isCompleted': false,
        'status': 'Not submitted',
        'earthWorkData':{},
        'defaultEarthWorkData':{},        
        'ownerName': this.userDetails['firstName'] +" " +this.userDetails['lastName'],
        'sortingSequence':this.configurationList.length +1
      })
      this.configurationList = [...this.configurationList]

      //adding new config data in list view data
      this.configTableData.push({
        'id': res,
        'name': request.configurationName,
        'minPileReveal': config['inputParameters'][0].value,
        'maxTTAxisSlope': config['inputParameters'][1].value,
        'revealWindow': config['inputParameters'][2].value,
        'maxSlopeChange': config['inputParameters'][3].value,
        'isBookmarked': false,
        'isCompleted': false,
        'isCompareChecked': false,
        'status': 'Not submitted',
        'earthWorkData': {},
        'defaultEarthWorkData':{},
        'unit': JSON.parse(JSON.stringify(this.selectedUnit)),
        'sortingSequence':this.configurationList.length +1,
        'isActive':false
      })
      this.configTableData = [...this.configTableData]

      this._cdr.detectChanges()
      // loading new added configuration slide
      this.slideIndex = this.configurationList.findIndex(conf => conf.name == request.configurationName) + 1;
      this.showSlides(this.slideIndex)
      this.updateEarthworkDataInGraph()
      this.arcgisService.clearMap();

    })
  }



  createConfigName() {
    // find the latest configuration to  create config name
    let configList = this.configurationList.filter(config =>!isNaN(parseInt(config.name.split(" ")[1])))
    let latestConfigName =configList.find(config =>config.id == Math.max(...configList.map(item => item.id))).name
    return 'Configuration ' + String(parseInt(latestConfigName.split(" ")[1]) + 1)
  }

  checkConfigExistence(data) {
    return this.configurationList.filter(config => config['inputParameters'][0]['value'] == data['inputParameters'][0]['value'] && config['inputParameters'][1]['value'] == data['inputParameters'][1]['value'] && config['inputParameters'][2]['value'] == data['inputParameters'][2]['value'] && config['inputParameters'][3]['value'] == data['inputParameters'][3]['value'])
  }

  //update reveal window value based on unit selection
  getRevealWindowValue(val) {
    if (val != 0) {
      let convertedVal = this.updateLength(this.selectedUnit.length, val, 'revealWindow')
      return convertedVal / 1000;
    } else { return 0 }
  }


  /** bookmark functionality */
  updateBookMarkOption(element) {

    //api service to update bookmark status in db
    this.service.updateBookmarkConfiguration(this.defaultAnalysisList['projectId'], element.id, this.defaultAnalysisList['layoutId']).then(res => {
    })
    this._cdr.detectChanges()
  }



  /** Delete configuration */
  deleteConfiguration(element) {
    this.service.deleteTerrainProConfiguration(this.defaultAnalysisList['projectId'], this.defaultAnalysisList['layoutId'], element.id).then(res => {
      let slideIndex = this.configurationList.findIndex(config => config.id == element.id)
      //removing connfig from navigation data
      this.configurationList = [...JSON.parse(JSON.stringify(this.configurationList.filter(config => config.id != element.id)))]

      //removing config from list view table
      this.configTableData = [...JSON.parse(JSON.stringify(this.configTableData.filter(config => config.id != element.id)))]
      this.updateSortingSequenceOrder()
      this._cdr.detectChanges()

      //loading the previous slide
      this.slideIndex = this.slideIndex - 1;
      this.showSlides(this.slideIndex)
    })
  }


  //rename configuration
  renameConfiguration(element) {
    let request = { 'configurationName': element.name }
    this.service.renameTerrainProConfiguration(this.defaultAnalysisList['projectId'], this.defaultAnalysisList['layoutId'], element.id, request).then(res => {
      //updating name in configuration list
      this.configurationList.filter(config => {
        if (config.id == element.id) {
          config.name = element.name
        }
      })
      //updating name in configuration table data
      this.configTableData.filter(config => {
        if (config.id == element.id) {
          config.name = element.name
        }
      })
      this._cdr.detectChanges()
    })
  }



  /** run configurations */
  runConfiguration() {
    this.socketService.awsSocketInit(String(this.defaultAnalysisList['projectId']) + '_' + String(this.defaultAnalysisList['layoutId']));
    let request = {
      'id': this.selectedConfig['id'],
      'terrainProLayoutId': this.defaultAnalysisList['layoutId'],
      'terrainproProjectId': this.defaultAnalysisList['projectId'],
      'source':'TP'
    }

    //check if initial solution(solution one) is available for this combination of minpile reveal and max-ttaxis slope change
    // condition is to check the config should not be not stated, min pile reveal and max tt axis slope must be same
    let isSolutionOneExists = this.configurationList.filter(config => config.status == 'Completed' && config['inputParameters'][0]['value'] == this.selectedConfig['inputParameters'][0]['value'] && config['inputParameters'][1]['value'] == this.selectedConfig['inputParameters'][1]['value'])

    //check if max slope change value is there or not, to run either solution 2 or 4
    let selectedSlopeChangeValue = this.selectedConfig['inputParameters'][3]['value']

    if (isSolutionOneExists.length == 0) {
      //solution one doesn't exist, based on max slope change value, trigger 2 (sol 1,2) or trigger chain 3(sol 1,3,4)
      request['chainToTrigger'] = selectedSlopeChangeValue == 0 ? 2 : 3;
    } else {
      //solution one exist, based on max slope change value, trigger 4 (sol 2) or trigger chain 5(sol 3,4)
      request['chainToTrigger'] = selectedSlopeChangeValue == 0 ? 4 : 5;
    }

    this.triggerConfigurationLoader.emit({ 'isShowLoader': true, 'msg': "Running configuration" })
    this.service.runConfiguration(request).then(res => {
      this.triggerConfigurationLoader.emit({ 'isShowLoader': false, 'msg': "Running configuration" })
      this.selectedConfig['status'] = 'Inprogress'      
      this.sharedService.resultTabComponent.isConfigurationCompleted = false;
      this.sharedService.resultTabComponent.isConfigurationInProgress = true;
      this.sharedService.resultTabComponent.isConfigurationFailed =  false;
      // updating status of config in navigator view
      this.configurationList.filter(config => {
        if (config.id == this.selectedConfig['id']) {
          config['status'] = 'Inprogress'
        }
      })

      // updating status of config in list view
      this.configTableData.filter(config => {
        if (config.id == this.selectedConfig['id']) {
          config['status'] = 'Inprogress'
        }
      })
      this._cdr.detectChanges()
    })


  }



  /** update progress in configuration list */
  updateConfigurationProgress(data) {
    let isConfigExist = this.configurationList.filter(config => config.id == data['id'])
    //if it is new configuration and it is not in the esiting list
    if (isConfigExist.length == 0 && Object.keys(data.configuration).length !== 0) {

      let inputs = JSON.parse(JSON.stringify(this.inputParameters))

      // mapping input values
      inputs.filter(item => {
        if (item.title == 'Minimum pile reveal') {
          item.value = data.configuration['minPileReveal']
          item.availableValues = data.availableValues['minPileReveal'] != undefined ? data.availableValues['minPileReveal'] : []
        } else if (item.title == 'Maximum TT-axis slope') {
          item.value = data.configuration['maxTTAxisSlope']
          item.availableValues = data.availableValues['maxTTAxisSlope'] != undefined ? data.availableValues['maxTTAxisSlope'] : []
          if(this.layoutInfo['racking'] == 'Ground fixed tilt' || this.layoutInfo['racking'] == 'Custom Stationary Fixed Tilt (Ground)'){
            item.alternativeTitle = 'Max E-W beam slope'
          }
        } else if (item.title == 'Reveal window') {
          item.value =this.sourceUnit == 'SI'? data.configuration['revealWindow'] * 1000 :data.configuration['revealWindow'] * 12
          item.availableValues = data.availableValues['revealWindow'] != undefined ?this.sourceUnit == 'SI'? data.availableValues['revealWindow'].map(x => x * 1000):data.availableValues['revealWindow'].map(x => x * 12) : []
        } else if (item.title == 'Maximum slope change') {
          item.value = data.configuration['maxSlopeChange']
          item.availableValues = data.availableValues['maxSlopeChange'] != undefined ? data.availableValues['maxSlopeChange'] : []
          if(this.layoutInfo['racking'] == 'Ground fixed tilt' || this.layoutInfo['racking'] == 'Custom Stationary Fixed Tilt (Ground)'){
            item.isDisabled = true;
          }
        }
      })

      //add the configuration in list and table
      this.configurationList.push({
        'id': data.id,
        'name': data.configuration.configurationName,
        'inputParameters': inputs,
        'isCompleted': data.configuration['isCompleted'],
        'status': data.configuration['status'],
        'defaultEarthWorkData':{},
        'earthWorkData': {},
        'ownerName': data.ownerName['firstName'] + " " + data.ownerName['lastName'],
        'sortingSequence':0
      })
      this.configurationList = [...this.configurationList]

      this.configTableData.push({
        'id': data.id,
        'name': data.configuration.configurationName,
        'minPileReveal': data.configuration['minPileReveal'],
        'maxTTAxisSlope': data.configuration['maxTTAxisSlope'],
        'revealWindow': this.sourceUnit == 'SI'? data.configuration['revealWindow'] * 1000:data.configuration['revealWindow'] * 12,
        'maxSlopeChange': data.configuration['maxSlopeChange'],
        'isBookmarked': data.configuration['isBookMarked'],
        'isCompleted': data.configuration['isCompleted'],
        'isCompareChecked': false,
        'status': data.configuration['status'],
        'defaultEarthWorkData':{},
        'earthWorkData': {},
        'unit': this.defaultUnit,
        'sortingSequence':0,
        'isActive':false
      })
      this.configTableData = [...this.configTableData]
      this.selectedUnit = { 'length': 'SI', 'angle': 'Degree', 'isDefaultUpdated': false }
      this.isDefaultUnit = false;
      this._cdr.detectChanges()
    }

    //updating the progress
    this.configurationList.filter(config => {
      if (config.id == data['id']) {
        //update completion status
        config['status'] = data['state'] == 'inprogress' ? 'Inprogress' : data['state'];
        config['isCompleted'] = data['state'] == 'Completed' || data['state'] == 'Failed' ? true : false;
      
        //update earthwork data in list 
        config['defaultEarthWorkData'] = 'earthworkData' in data['configuration'] ? data['configuration']['earthworkData']:{}
        // config['earthWorkData']= 'earthworkData' in data['configuration'] ?this.updateUnitConversionInEarthworkData(data['configuration']['earthworkData']):{}
        
        if('earthworkData' in data['configuration'] ){
          if('isUpdatedVersion' in data['configuration']['earthworkData'] && data['configuration']['earthworkData']['isUpdatedVersion']){
            config['earthWorkData']= this.updateUnitInEarthworkData(data['configuration']['earthworkData'], this.sourceUnit, this.selectedUnit)
          }else{
            config['earthWorkData']= this.updateUnitConversionInEarthworkData(data['configuration']['earthworkData'])
          }
        }else{   config['earthWorkData']={}}
        
        //update selected value and available value in list
        config['inputParameters'].filter(conf => {
          if (conf.title == 'Reveal window' && data['configuration']['revealWindow'] != undefined ) {
            if(this.sourceUnit == 'SI'){
              if( this.selectedUnit.length == 'SI' ){
                // m to mm (*1000)
                conf.value = conf.value != data['configuration']['revealWindow']* 1000 ? data['configuration']['revealWindow'] * 1000 : conf.value;
                conf.availableValues  = data.availableValues['revealWindow'] != undefined ? data.availableValues['revealWindow'].map(x => x * 1000) :[]
                conf.unit = 'mm'
              }else{
                // m to inches
                conf.value = conf.value !=this.updateLength( 'SI' , data['configuration']['revealWindow']* 1000,'revealWindow') ?this.updateLength( 'SI' , data['configuration']['revealWindow']* 1000,'revealWindow') : conf.value;
                conf.availableValues  = data.availableValues['revealWindow'] != undefined ?data.availableValues['revealWindow'].map(x => this.updateLength( 'SI' ,x * 1000,'revealWindow')) : []
                conf.unit = 'in'
              }
            }else{
              if( this.selectedUnit.length == 'SI' ){
                // ft to mm (* 304.8)
                conf.value = conf.value != data['configuration']['revealWindow']* 304.8 ? data['configuration']['revealWindow'] * 304.8 : conf.value;
                conf.availableValues  = data.availableValues['revealWindow'] != undefined ? data.availableValues['revealWindow'].map(x => x * 304.8) :[]
                conf.unit = 'mm'
              }else{
                //ft to in (*12)
                conf.value = conf.value !=data['configuration']['revealWindow']* 12 ?data['configuration']['revealWindow']* 12 : conf.value;
                conf.availableValues  = data.availableValues['revealWindow'] != undefined ?data.availableValues['revealWindow'].map(x =>x*12) : []
                conf.unit = 'in'
              }

            }
           
          
          }else if(conf.title == 'Maximum TT-axis slope' && data['configuration']['maxTTAxisSlope'] != undefined ) {
            if(this.selectedUnit.angle == 'Degree'  ){
              conf.value = conf.value != data['configuration']['maxTTAxisSlope']? data['configuration']['maxTTAxisSlope'] : conf.value
              conf.availableValues  = data.availableValues['maxTTAxisSlope'] != undefined ? data.availableValues['maxTTAxisSlope'] :[]   
              conf.unit ='°'
            }else{
              conf.value = conf.value !=this.updateAngle('Degree', data['configuration']['maxTTAxisSlope']) ?this.updateAngle('Degree', data['configuration']['maxTTAxisSlope'])  : conf.value
              conf.availableValues  = data.availableValues['maxTTAxisSlope'] != undefined ?data.availableValues['maxTTAxisSlope'].map(x =>this.updateAngle('Degree', x) ): []
              conf.unit = '%'
            }
          
            }
        })
        
      this._cdr.detectChanges()
      }
    })

    //updating completion in table data
    this.configTableData.filter(config => {
      if (config.id == data['id']) {
        //update completion status
        config['status'] = data['state'] == 'inprogress' ? 'Inprogress' : data['state'];
        config['isCompleted'] = data['state'] == 'Completed' || data['state'] == 'Failed' ? true : false;
       
        //update earthwork data in list 
        config['defaultEarthWorkData'] = 'earthworkData' in data['configuration'] ? data['configuration']['earthworkData']:{}
        // config['earthWorkData']= 'earthworkData' in data['configuration'] ?this.updateUnitConversionInEarthworkData(data['configuration']['earthworkData']):{}
        if('earthworkData' in data['configuration']){
          if('isUpdatedVersion' in data['configuration']['earthworkData'] && data['configuration']['earthworkData']['isUpdatedVersion']){
            config['earthWorkData']= this.updateUnitInEarthworkData(data['configuration']['earthworkData'], this.sourceUnit, this.selectedUnit)
          }else{
            config['earthWorkData']= this.updateUnitConversionInEarthworkData(data['configuration']['earthworkData'])
          }
        }else{
          config['earthWorkData']={}
        }

        if (this.sourceUnit == 'SI') {
          //update selected value and available value in list
          if (this.selectedUnit.length == 'SI') {
            //m to mm
            config['revealWindow'] = config['revealWindow'] != data['configuration']['revealWindow'] * 1000 && data['configuration']['revealWindow'] != undefined ? data['configuration']['revealWindow'] * 1000 : config['revealWindow']
            config['minPileReveal'] = config['minPileReveal'] != data['configuration']['minPileReveal'] && data['configuration']['minPileReveal'] != undefined ? data['configuration']['minPileReveal'] : config['minPileReveal']

          } else {
            // m to inches and m to ft
            config['revealWindow'] = config['revealWindow'] != this.updateLength('SI', data['configuration']['revealWindow'] * 1000, 'revealWindow') && data['configuration']['revealWindow'] != undefined ? this.updateLength('SI', data['configuration']['revealWindow'] * 1000, 'revealWindow') : config['revealWindow']
            config['minPileReveal'] = config['minPileReveal'] != this.updateLength('SI', data['configuration']['minPileReveal'], 'minPileReveal') && data['configuration']['minPileReveal'] != undefined ? this.updateLength('SI', data['configuration']['minPileReveal'], 'minPileReveal') : config['minPileReveal']
          }
        } else {
          //update selected value and available value in list
          if (this.selectedUnit.length == 'SI') {
            // ft to m (/ 3.281) and ft to mm (*304.8)
            config['revealWindow'] = config['revealWindow'] != data['configuration']['revealWindow'] * 304.8 && data['configuration']['revealWindow'] != undefined ? data['configuration']['revealWindow'] * 304.8 : config['revealWindow']
            config['minPileReveal'] = config['minPileReveal'] != data['configuration']['minPileReveal'] / 3.281 && data['configuration']['minPileReveal'] != undefined ? data['configuration']['minPileReveal'] / 3.281 : config['minPileReveal']

          } else {
            // ft to in
            config['revealWindow'] = config['revealWindow'] != data['configuration']['revealWindow'] * 12 && data['configuration']['revealWindow'] != undefined ? data['configuration']['revealWindow'] * 12 : config['revealWindow']
            config['minPileReveal'] = config['minPileReveal'] != data['configuration']['minPileReveal'] && data['configuration']['minPileReveal'] != undefined ? data['configuration']['minPileReveal'] : config['minPileReveal']
          }
        }

       
            
        if(this.selectedUnit.angle == 'Degree'  ){
          config['maxTTAxisSlope'] = config['maxTTAxisSlope'] != data['configuration']['maxTTAxisSlope'] && data['configuration']['maxTTAxisSlope'] != undefined ? data['configuration']['maxTTAxisSlope']  : config['maxTTAxisSlope']
          config['maxSlopeChange'] = config['maxSlopeChange'] != data['configuration']['maxSlopeChange'] && data['configuration']['maxSlopeChange'] != undefined ? data['configuration']['maxSlopeChange']  : config['maxSlopeChange']  
        }else{
          config['maxTTAxisSlope'] = config['maxTTAxisSlope'] !=this.updateAngle('Degree', data['configuration']['maxTTAxisSlope'])  && data['configuration']['maxTTAxisSlope'] != undefined ?this.updateAngle('Degree', data['configuration']['maxTTAxisSlope'])   : config['maxTTAxisSlope']
          config['maxSlopeChange'] = config['maxSlopeChange'] !=this.updateAngle('Degree', data['configuration']['maxSlopeChange'])  && data['configuration']['maxSlopeChange'] != undefined ?this.updateAngle('Degree', data['configuration']['maxSlopeChange'])   : config['maxSlopeChange']
        }

        config.unit['angle'] =this.selectedUnit.angle
        config.unit['length'] = this.selectedUnit.length

          this._cdr.detectChanges()
      }
    })

    //updating progress in ui         
    if(this.selectedConfig['id']== data['id'] ){
      this.selectedConfig['status']= data['state'] == 'inprogress' ? 'Inprogress' : data['state'];
      this.sharedService.resultTabComponent.isConfigurationCompleted = data['state'] == 'Completed'? true: false;
      this.sharedService.resultTabComponent.isConfigurationInProgress = data['state'] == 'inprogress'? true: false;
      this.sharedService.resultTabComponent.isConfigurationFailed =  data['status'] == 'Failed'? true: false;

    }
    if (data['state'] == 'Completed' && data['progress'] == 100) {
      //updating default list
      if (this.isInitialRun) {
        this.service.getTerrainProConfigurations(data['projectId'],data['layoutId']).then(res => {
          this.defaultAnalysisList = res;
          this.layoutInfo = res.layoutInfo;
          this.layoutInfo['boundaryArea']=Math.trunc(this.layoutInfo['boundaryArea']*Math.pow(10, 1))/Math.pow(10, 1)//truncating with one decimal
          this.layoutInfo['rowSpacing']=Math.trunc(this.layoutInfo['rowSpacing']*Math.pow(10, 1))/Math.pow(10, 1)//truncating with one decimal
          this.formLayoutInfo( res.layoutInfo)
          this.selectedUnit = res.unitSelection;
          this.setDefaultRevealWindowConfiguration()
          //update order in navigation data and list view data
          this.configurationList = this.initializeSortingSequence(this.configurationList, true)
          this.configTableData = this.initializeSortingSequence(this.configTableData,false)
          this.configurationList =[...this.configurationList]
          this.configTableData = [...this.configTableData]

        })
        this.configurationLoaded.emit()
        this.isInitialRun = false;
      } else{   
        this._cdr.detectChanges()
      // if state of selected configuration is completed , then get solution 
      let isSelectedConfigCompleted = this.configurationList.filter(config => config.id == this.selectedConfig['id'] && config['isCompleted'])
      if(isSelectedConfigCompleted.length !=0){
        this.getSolution(this.defaultAnalysisList['projectId'], this.defaultAnalysisList['layoutId'], this.selectedConfig['id'])
     
      }
      }
    }

    this._cdr.detectChanges()
  }



  /** Configuartion related code - END */




  /** input selection modal related code */


  /** update user input */
  updateInputSelection(data) {
    let selectedConfiguration = JSON.parse(JSON.stringify(this.selectedConfig))
    selectedConfiguration['inputParameters'].filter(item => {
      if (item.title == data.title) {
        item.value = data.selectedValue
        item.availableValues = data.parameters
      }
    })
   let minPileRevealValues =[];
   let revealWindowValues = [];
   let ttAxisSlopeValues = [];
   let slopeChangeValues = [];


    if(this.sourceUnit == 'SI'){
    //updating values to default unit before calling api 
     minPileRevealValues = this.selectedUnit.length == 'SI' ? selectedConfiguration['inputParameters'][0].availableValues : selectedConfiguration['inputParameters'][0].availableValues.map(x => this.updateLength(this.selectedUnit.length, x, 'minPileReveal'))
     revealWindowValues = this.selectedUnit.length == 'SI' ? selectedConfiguration['inputParameters'][2].availableValues.map(x => Number((x / 1000).toFixed(4))) : selectedConfiguration['inputParameters'][2].availableValues.map(x => this.getRevealWindowValue(x))
     ttAxisSlopeValues = this.selectedUnit.angle == 'Degree' ? selectedConfiguration['inputParameters'][1].availableValues : selectedConfiguration['inputParameters'][1].availableValues.map(x => this.updateAngle(this.selectedUnit.angle, x))
     slopeChangeValues = this.selectedUnit.angle == 'Degree' ? selectedConfiguration['inputParameters'][3].availableValues : selectedConfiguration['inputParameters'][3].availableValues.map(x => this.updateAngle(this.selectedUnit.angle, x))
    }else{
      minPileRevealValues = this.selectedUnit.length == 'SI' ? selectedConfiguration['inputParameters'][0].availableValues.map(x=>Number((x*3.281)).toFixed(4)) : selectedConfiguration['inputParameters'][0].availableValues
     revealWindowValues = this.selectedUnit.length == 'SI' ? selectedConfiguration['inputParameters'][2].availableValues.map(x => Number((x / 304.8 ) ).toFixed(4)): selectedConfiguration['inputParameters'][2].availableValues.map(x => Number((x/12).toFixed(4)))
     ttAxisSlopeValues = this.selectedUnit.angle == 'Degree' ? selectedConfiguration['inputParameters'][1].availableValues : selectedConfiguration['inputParameters'][1].availableValues.map(x => this.updateAngle(this.selectedUnit.angle, x))
     slopeChangeValues = this.selectedUnit.angle == 'Degree' ? selectedConfiguration['inputParameters'][3].availableValues : selectedConfiguration['inputParameters'][3].availableValues.map(x => this.updateAngle(this.selectedUnit.angle, x))

    }
    //available values for each input
    let availableVal = {
      'minPileReveal': minPileRevealValues,
      'maxTTAxisSlope': ttAxisSlopeValues,
      'revealWindow': revealWindowValues,
      'maxSlopeChange': slopeChangeValues,
    }
    // selected value for each input
    let configData = {}
    if(this.sourceUnit == 'SI'){
     configData = {
      'minPileReveal': this.selectedUnit.length == 'SI' ? selectedConfiguration['inputParameters'][0].value : this.updateLength(this.selectedUnit.length, selectedConfiguration['inputParameters'][0].value, 'minPileReveal'),
      'maxTTAxisSlope': this.selectedUnit.angle == 'Degree' ? selectedConfiguration['inputParameters'][1].value : this.updateAngle(this.selectedUnit.angle, selectedConfiguration['inputParameters'][1].value),
      'revealWindow': this.selectedUnit.length == 'SI' ? selectedConfiguration['inputParameters'][2].value != 0 ? selectedConfiguration['inputParameters'][2].value / 1000 : selectedConfiguration['inputParameters'][2].value : this.getRevealWindowValue(selectedConfiguration['inputParameters'][2].value),
      'maxSlopeChange': this.selectedUnit.angle == 'Degree' ? selectedConfiguration['inputParameters'][3].value : this.updateAngle(this.selectedUnit.angle, selectedConfiguration['inputParameters'][3].value),
    }
  }else{
    configData = {
      'minPileReveal': this.selectedUnit.length == 'SI' ? selectedConfiguration['inputParameters'][0].value * 3.281: selectedConfiguration['inputParameters'][0].value,
      'maxTTAxisSlope': this.selectedUnit.angle == 'Degree' ? selectedConfiguration['inputParameters'][1].value : this.updateAngle(this.selectedUnit.angle, selectedConfiguration['inputParameters'][1].value),
      'revealWindow': this.selectedUnit.length == 'SI' ? selectedConfiguration['inputParameters'][2].value != 0 ? selectedConfiguration['inputParameters'][2].value /  304.8 : selectedConfiguration['inputParameters'][2].value :selectedConfiguration['inputParameters'][2].value/12,
      'maxSlopeChange': this.selectedUnit.angle == 'Degree' ? selectedConfiguration['inputParameters'][3].value : this.updateAngle(this.selectedUnit.angle, selectedConfiguration['inputParameters'][3].value),
    }
  }


    //check if configuration already exist
    let config = this.checkConfigExistence(selectedConfiguration)

    //if configuration already exist
    if (config.length != 0) {
      this.selectedConfig = config[0]

       //update config status in result tab      
       this.sharedService.resultTabComponent.isConfigurationCompleted =  this.selectedConfig['status'] == 'Completed'? true: false;
       this.sharedService.resultTabComponent.isConfigurationInProgress =  this.selectedConfig['status'] == 'Inprogress'? true: false;
       this.sharedService.resultTabComponent.isConfigurationFailed =  this.selectedConfig['status'] == 'Failed'? true: false;
 
      this.slideIndex = this.configurationList.findIndex(conf => conf.name == this.selectedConfig.name) + 1;
      //loading the configuration slide in UI
      this.showSlides(this.slideIndex)
      let req = { 'id': config[0]['id'], 'availableValues': availableVal, 'layoutId': this.defaultAnalysisList['layoutId'], 'projectId': this.defaultAnalysisList['projectId'], 'updatedConfig': configData }
      this.getSolution(this.defaultAnalysisList['projectId'], this.defaultAnalysisList['layoutId'], config[0]['id'])  
      this.updateEarthworkDataInGraph()
      this.service.updateTerrainProConfiguration(req).then(res => { })
    } else {
      //add the new value in all configurations
      this.configurationList.filter(config=>{
        config['inputParameters'].filter(input=>{
          if(input.title == data.title){
            input.availableValues = JSON.parse(JSON.stringify(data.parameters))
          }
        })
      })

      // if input is updated in not submitted configuration , the just update availables and selected value in the same configuration
      if (selectedConfiguration.status == 'Not submitted') {
        this.selectedConfig = JSON.parse(JSON.stringify(selectedConfiguration))
      
       //update config status in result tab      
      this.sharedService.resultTabComponent.isConfigurationCompleted =  this.selectedConfig['status'] == 'Completed'? true: false;
      this.sharedService.resultTabComponent.isConfigurationInProgress =  this.selectedConfig['status'] == 'Inprogress'? true: false;
      this.sharedService.resultTabComponent.isConfigurationFailed =  this.selectedConfig['status'] == 'Failed'? true: false;

        let req = { 'id': selectedConfiguration['id'], 'availableValues': availableVal, 'layoutId': this.defaultAnalysisList['layoutId'], 'projectId': this.defaultAnalysisList['projectId'], 'updatedConfig': configData }
        this.configTableData.filter(config => {
          if (config.id == selectedConfiguration['id']) {
            config['minPileReveal'] = selectedConfiguration['inputParameters'][0].value
            config['maxTTAxisSlope'] = selectedConfiguration['inputParameters'][1].value
            config['revealWindow'] = selectedConfiguration['inputParameters'][2].value
            config['maxSlopeChange'] = selectedConfiguration['inputParameters'][3].value
          }
        })

        this.configurationList.filter(config => {
          if(config.id == selectedConfiguration.id){
            config['inputParameters']=JSON.parse(JSON.stringify(selectedConfiguration['inputParameters']))
          }
        })
        this.service.updateTerrainProConfiguration(req).then(res => { })
      }
      else {

        //if input is updated in completed/ submitted configuration , adding new configuration
        this.createNewConfiguration(selectedConfiguration, availableVal)
      }
    }

    // closing the input selection modal 
    this.showInputSelectionModal = false;
    this.inputSelectionObject = {};
    this._cdr.detectChanges()
  }


  /** open input selection modal */
  openSelectionModal(selectedInput) {
    // set default value to active variable
    this.selectedConfig['inputParameters'].filter(x => {
      x.active = false
    })
    selectedInput['active'] = true;
    this.activeBorder = true;
    /** loading icon based clicked input parameter */
    let iconName = ''
    let msg=''
    if (selectedInput.title === 'Minimum pile reveal') {
      iconName = 'pileRevealIcon';
      msg ='This term refers to the vertical distance between the top of a pile foundation and the adjacent ground elevation. Pile reveal does not include the embedment of the pile and refers only to the part of a pile visible above ground. Pile reveal is sometimes referred to as, “pile height”.'
    } else if (selectedInput.title === 'Maximum TT-axis slope') {
      iconName = 'axisSlopeIcon';
      msg = 'The maximum torque tube axis slope is equal to the absolute value of the delta in elevation between two adjacent piles divided by the horizontal distance between them. The slope is measured from the horizontal to the axis of the torque tube.'
    } else if (selectedInput.title === 'Reveal window') {
      iconName = 'revealWindowIcon'
      msg ='The reveal window is the vertical distance between the minimum pile reveal and the maximum pile reveal. The reveal window is added to the minimum pile reveal to obtain the total pile reveal, or the portion of the pile above grade. The reveal window is sometimes referred to as the “undulation tolerance” or the “grading tolerance”. Formula: Reveal Window = Maximum Pile reveal - Minimum Pile Reveal'
    } else {
      iconName = 'maxSlopeIcon'
      msg='The maximum slope change is the maximum change in slope between adjacent tables. Terrain following single axis trackers articulate at a point or points along their length. The allowable articulation defines the maximum change in slope at those points of articulation.'
    }

    this.formInputSelectionData(selectedInput['title'], selectedInput['unit'], selectedInput['availableValues'], iconName, selectedInput['value'],msg,selectedInput['alternativeTitle'])
    // display input selection modal 
    this.showInputSelectionModal = true;
  }


  /** close selection window */
  closeSelectionWindow() {
    // hide input selection modal 
    this.showInputSelectionModal = false;
    this.inputSelectionObject = {};
    this._cdr.detectChanges()
    // set default value to active variable after close window
    this.selectedConfig['inputParameters'].filter(x => {
      x.active = false
    })
    this.activeBorder = false;
  }


  /** form input selection popup data*/
  formInputSelectionData(title, unit, parameters, iconName, value,msg, alternativeTitle) {
    this.inputSelectionObject = {}
    var name = title[0].toLowerCase() + title.slice(1);
    this.inputSelectionObject['title'] = title;
    this.inputSelectionObject['unit'] = unit
    this.inputSelectionObject['parameters'] = parameters
    this.inputSelectionObject['iconName'] = iconName
    this.inputSelectionObject['selectedValue'] = value
    this.inputSelectionObject['name'] = name
    this.inputSelectionObject['text'] = msg
    this.inputSelectionObject['alternativeTitle'] = alternativeTitle !=''?  alternativeTitle[0].toLowerCase() + alternativeTitle.slice(1):alternativeTitle
  }


  /** input selection modal related code - END */





  /** Download functionalities
   * this section of code covers download of below :
   * Download solution,tracker geojson, input csv in zip format
   * Download configuration report
   */

  isDownloadBtnDisabled(){
return this.selectedConfig['status'] == 'Completed'?false:true;
  }

  isDownloadReportDisabled(){
return Object.keys(this.selectedConfig['earthWorkData']).length == 0 ? true:false;
  }



  //download solution file
  downloadSolution() {
    let res = this.solutionData.filter(solution => solution.id == this.selectedConfig['id'])[0]
    //creating file name format
    let date = formatDate(new Date(), 'yyyy-MM-dd-HH-mm', 'en-US')
    var input_name = this.layoutInfo.projectName + 'input' + date + '.csv'
    var solutionFileName = this.layoutInfo.projectName + '_' + this.selectedConfig.name + '_' + date + '_solution.csv'
    var zipName = 'Terrainpro_' + this.layoutInfo.projectName + '_' + date+ '.zip'
    //creating csv file for input piles data
    var csvData = this.createCSVData(res['solution']);
    let zip = new JSZip();
    // zip.file(solutionFileName, JSON.stringify(res['solution']));
    zip.file(solutionFileName, csvData);
    // zip.file('tracker_geojson.json', JSON.stringify(res['geojson']));
    JSZip.support.nodebuffer = false;
    zip.generateAsync({
      type: "blob"
    }).then((content) => {
      let fileName = zipName
      FileSaver.saveAs(content, fileName);
    });
  }

  //creating json into CSV format function 
  createCSVData(data) {
    let solutionDataofPiles = []
    let isAlphaAngleAvailable = 'alpha' in data[0]['piles'][0]['Solution']? true:false;
    data.forEach(tracker => {
      tracker['piles'].forEach(pile => {
        let solution_data = {}
        solution_data["PileID"] =pile['PileId']
        solution_data["RackID"]= tracker.trackerId
        solution_data["Easting"]=pile['Position_utm']['Easting']
        solution_data["Northing"]=pile['Position_utm']['Northing']
        solution_data["ExistingGrade"]=pile['Elevation']
        solution_data["PileName"]=pile['PileName']
        solution_data["RackName"] =tracker.trackerName
        solution_data["FinishGrade"]=pile['Solution']['Bottom']
        solution_data["PileReveal"]=pile['Solution']['PileHeight']
        solution_data["TopofPile"]=pile['Solution']['Top']
        if(isAlphaAngleAvailable){
          solution_data["Alpha"]=pile['Solution']['alpha']
          solution_data["Beta"]=pile['Solution']['beta']
          solution_data["ArticulationAngle"]=pile['Solution']['ArticulatorAngle']
        }       
        solutionDataofPiles.push(solution_data)

      });
    });
    const csv_Header = {
      'PileID': 'PileID',
      'RackID':'RackID',
      'Easting': 'Easting',
      'Northing': 'Northing',
      'ExistingGrade': 'ExistingGrade',
      'PileName':'PileName',
      'RackName':'RackName',
      'FinishGrade': 'FinishGrade',
      'PileReveal': 'PileReveal',
      'TopofPile': 'TopofPile'
    }
    if(isAlphaAngleAvailable){
      csv_Header['Alpha'] ='Alpha'
      csv_Header['Beta'] = 'Beta'
      csv_Header['ArticulationAngle']='ArticulationAngle'
    }
    solutionDataofPiles.splice(0, 0, csv_Header);
    return this.convertToCSV(solutionDataofPiles,isAlphaAngleAvailable)
  }

  // convert solution array of object to csv format
  convertToCSV(arrayValue, isAngleAvailable) {
    const header = ["PileID","RackID", "Easting", "Northing", "ExistingGrade","PileName","RackName", "FinishGrade", "PileReveal", "TopofPile"];
    if(isAngleAvailable){
      header.push("Alpha","Beta","ArticulationAngle")
    }

    const replacer = (key, values) => values === null ? '' : values // specify how you want to handle null values here
    let csvData = arrayValue.map(row => header.map(fieldName => replacer(fieldName, row[fieldName])).join(','))
    csvData = csvData.join('\r\n');
    return csvData
  }


  //download terrain pro earth work summary report
  async downloadEarthWorkReport() {
    var inputJson = this.createEarthWorkReportJson();
    const reportMapDiv = document.getElementById('report-map-div')
    reportMapDiv.style.visibility = 'visible';
    //Include heat map image data url into report generation
    var dataUrl = await this.snapShotService.loadEarthworkHeatMapData()
    var _this = this
    inputJson['heatMapDataUrl'] = dataUrl
    reportMapDiv.style.visibility = 'hidden';
     _this.service.downloadEarthWorkReport(_this.defaultAnalysisList['projectId'], _this.defaultAnalysisList['layoutId'], _this.selectedConfig['id'], inputJson).then(pdfData => {
      //Downlad the reports docx file
      var downloadTag: any = document.createElement("a");
      document.body.appendChild(downloadTag);
      var url = window.URL.createObjectURL(pdfData);
      downloadTag.href = url;
      downloadTag.download = 'earthwork_' + _this.layoutInfo['projectName'] + '_' + _this.layoutInfo['layoutName'] + '.pdf';
      downloadTag.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(downloadTag);
      this.sharedService.terrainProTopBarComponent.isReportDownload = false
    }, error => {

    })

  }

  //create earth work report json
  createEarthWorkReportJson() {

    var pipe = new DatePipe('en-US');
    var date = pipe.transform(Date.now(), 'dd/MM/yyyy');
    var timeStamp = pipe.transform(Date.now(), 'hh:mm:ss a');
    let minRevealUnit = this.selectedConfig['inputParameters'][0].unit == 'm' ? 'meters' : 'feet'
    let revealWindowUnit = this.selectedConfig['inputParameters'][2].unit == 'mm' ? 'millimeters' : 'inches'
    let angleUnit = this.selectedConfig['inputParameters'][1].unit == '°' ? 'degrees' : '%'
    var inputJson = {
      'projectName': this.layoutInfo['projectName'],
      'layoutName': this.layoutInfo['layoutName'],
      'date': date,
      'time': timeStamp,
      'author': this.selectedConfig['ownerName'],
      'configurationName': this.selectedConfig['name'],
      'city':'location'in this.layoutInfo? this.layoutInfo['location'].split(',')[0]:'',
      'state': 'location'in this.layoutInfo? this.layoutInfo['location'].split(',')[1]:'',
      'country': 'location'in this.layoutInfo? this.layoutInfo['location'].split(',').length > 2 ? this.layoutInfo['location'].split(',')[2] : this.layoutInfo['location'].split(',')[1]:'',
      'latitude': this.defaultAnalysisList['lat'].toFixed(4),
      'longitude': this.defaultAnalysisList['long'].toFixed(4),
      'minimumPileReveal': this.selectedConfig['inputParameters'][0].value.toFixed(3) + ' ' + minRevealUnit,
      'maximumAxisSlope': this.selectedConfig['inputParameters'][1].value.toFixed(2) + ' ' + angleUnit,
      'revealWindow': parseInt(this.selectedConfig['inputParameters'][2].value.toFixed()) + ' ' + revealWindowUnit,
      'maximumSlopeChange': this.selectedConfig['inputParameters'][3].value.toFixed(2) + ' ' + angleUnit,
      'unit': this.selectedUnit,
      'arrayArea': this.selectedConfig['earthWorkData']['area']['totalArrayArea'].toFixed(4),
      'epsgCode': 'wkid' in this.layoutInfo ? this.layoutInfo['wkid']!=undefined ?String( this.layoutInfo['wkid']) :'':'',
      'elevationSource':  this.isMercatorConfigurations? 'provided by user':this.layoutInfo['elevationSource']!=undefined ? this.layoutInfo['elevationSource'] :'',
      'elevationResolution': this.isMercatorConfigurations? 'Not available': this.layoutInfo['pixelSize']!=undefined ? String(this.layoutInfo['pixelSize'].toFixed(2)):'',
      'isGFT':this.layoutInfo['racking'] == 'Ground fixed tilt' || this.layoutInfo['racking'] == 'Custom Stationary Fixed Tilt (Ground)'? true:false,
      'earthWork': {
        'volume': {
          'totalGrading': Math.abs(this.selectedConfig['earthWorkData']['volume']['totalGrading'].toFixed()).toLocaleString(),
          'cutVolume':  Math.abs(this.selectedConfig['earthWorkData']['volume']['cutVolume'].toFixed()).toLocaleString(),
          'fillVolume':  Math.abs(this.selectedConfig['earthWorkData']['volume']['fillVolume'].toFixed()).toLocaleString(),
          'netExport': Math.abs(this.selectedConfig['earthWorkData']['volume']['netExportVolume'].toFixed()).toLocaleString(),
          'cutFillRatio':  Math.abs(this.selectedConfig['earthWorkData']['volume']['cutFillRatio'].toFixed(3)).toLocaleString(),
          'unit': this.selectedUnit.length == 'SI'?'bcm':'bcy'
        },
        'area': {
          'totalDistributedArea': Math.abs(this.selectedConfig['earthWorkData']['area']['totalDisturbedArea'].toFixed(2)).toLocaleString(),
          'cutArea': Math.abs(this.selectedConfig['earthWorkData']['area']['cutArea'].toFixed(2)).toLocaleString(),
          'fillArea':Math.abs( this.selectedConfig['earthWorkData']['area']['fillArea'].toFixed(2)).toLocaleString(),
          'distributedArea': Math.abs(this.selectedConfig['earthWorkData']['area']['disturbedPercent'].toFixed(2)).toLocaleString(),
          'unit':  this.selectedUnit.length == 'SI'?'ha':'ac'
        },
        'depth': {
          'maxCut': Math.abs(this.selectedConfig['earthWorkData']['depth']['maxCut'].toFixed(2)).toLocaleString(),
          'maxFill': Math.abs(this.selectedConfig['earthWorkData']['depth']['maxFill'].toFixed(2)).toLocaleString(),
          'unit':  this.selectedUnit.length == 'SI'?'m':'ft'
        }
      }
    }

    return inputJson;
  }

  //check the text chartcters and show the shorter version in the mouse over
  tooltipCharCheck(valueString, digit) {
    message = '';
    if (valueString != undefined) {
      var message = valueString.length > digit ? valueString : '';
    }
    this.titleMessage = message;

    return message;
  }


  /** Download functionalities - END */




  /** compare functionalities - START**/


  //cancel compare
  cancelCompare() {
    setTimeout(() => {
      //uncheck compare for all data in table view
      this.configTableData.filter(config => config.isCompareChecked = false)
      this.configTableData = [...this.configTableData]
      this.compareConfigurationList = []
    }, 100)

  }

  cancelCompareOption(e) {
    setTimeout(() => {
      //remove config from compare list and uncheck in table view
      this.configTableData.filter(config => { if (config.id == e.id) { config.isCompareChecked = false } })
      this.configTableData = [...this.configTableData]
      this.compareConfigurationList = this.compareConfigurationList.filter(config => config.id != e.id)
    }, 100)
  }

  //checking if compare option checked
  isCompareChecked() {
    let config = this.configTableData.filter(config => config.isCompareChecked == true)
    return config.length != 0 ? true : false;
  }

  //updating compare checkbox event
  updateCompareOption(e) {
    if (e.status) {
      //if status is checked, then add config to compare list
      this.compareConfigurationList.push(e.element)
    } else {
      //if status is unchecked, then remove config from compare list
      this.compareConfigurationList = this.compareConfigurationList.filter(config => config.id != e.element.id)
    }
  }

  showCompare() {
    this.showCompareModal = true;
    this.showConfigurationList()
  }


  // compare modal functionalities
  closeCompareModal() {
    this.showCompareModal = false;
  }

  /** compare functionalities - END **/




  /** Map related functionalities */
  loadDataInMap() {
    this.arcgisService.jsonFeatures['Trackers'] = this.selectedSolution['solution']
    this.arcgisService.selectedConfigId = this.selectedSolution['id']
    //calling loadpileAnalysisLayer to load solution data in map
    if(this.arcgisService.view != undefined && !this.arcgisService.pileAnaylsisStarted){ //  check if the map view loaded
      console.log('From load data in map function') 
      this.arcgisService.loadpileAnalysisLayer()
    }
  }


  //retrieve solution from api and update map
  getSolution(projectId, layoutId, configId,isConfigurationChange=false) {
    this.arcgisService.pileAnaylsisStarted = false

    //check if selected configuration is submitted configuration
    if (this.selectedConfig['status'] != 'Not submitted') {

      //check if solution data for selected configuration is available or not       
      let isSolutionExist = this.solutionData.filter(sol => sol.id == configId)
      if (isSolutionExist.length == 0) {
        //if solution doesn't exist ,then call api and get solution for the selected configuration and map data in map and profile viewer

        this.triggerConfigurationLoader.emit({ 'isShowLoader': true, 'msg': "Retrieving solution" })
        this.solutionData.push({ 'id': configId })

        //api to get solution of configuration
        this.service.downloadSolution(projectId, layoutId, configId).then(res => {
         this.profileViewerData = {}
          //update unit in the solution
          if (res['solution'].length != 0) {
            res['solution'].filter(tracker => {
              tracker.piles.filter(pile => {
                pile['Solution']['unit'] = this.sourceUnit =='SI'? 'm':'ft';
              })
            })

            // update solution, geojson data in our solution data list
            this.solutionData.filter(sol => {
              if(sol.id == configId){
                sol['solution'] = res['solution']
                sol['geojson'] =res['geojson']
                sol['profileViewerData'] =this.updateUnitInProfileViewer(isConfigurationChange,sol)
                this.selectedSolution = sol
            }})

            this.graphService.minimumPilereveal = this.selectedConfig.inputParameters[0]['value'];
            this.graphService.maximumPileHeight = this.selectedConfig.inputParameters[0]['value'] + (this.selectedConfig.inputParameters[2]['value'] / 1000);
            this.updateUnitChange(isConfigurationChange)
          }else {
            this.triggerConfigurationLoader.emit({ 'isShowLoader': false, 'msg': "Retrieving solution" })
            this.arcgisService.clearMap() // clear the map when the configuration is not submitted
          }          
          return res
        })
      }
      else {

        this.profileViewerData = {}
        // if solution for selected configuration exist, then filter it and set as selectedSolution
        // load selected configuration's solution in map and tracker profileviewer

        // check the keys 'solution' and 'geojson' available in solution data
        let solution = this.solutionData.filter(sol => sol.id == configId)[0]
        if('solution' in solution && 'geojson' in solution){
          this.selectedSolution = solution;
          this.profileViewerData = solution['profileViewerData'] 
          this.updateUnitChange(isConfigurationChange)
          this.loadDataInMap()

          // updating graph related data
          this.graphService.minimumPilereveal = this.selectedConfig.inputParameters[0]['value'];
          this.graphService.maximumPileHeight = this.selectedConfig.inputParameters[0]['value']; +(this.selectedConfig.inputParameters[2]['value'] / 1000);
          this.graphService.createTrackerLayoutArray(isConfigurationChange);
        }
        
      }
    } else {
      this.arcgisService.clearMap() // clear the map when the configuration is not submitted
    }


  }


  /*** Earth work related code section */


  /***earthworkdata update */
  updateEarthworkData(data,projectId,layoutId,id){
    let earthworkDataInDefaultUnit = this.formEarthWorkData(data)
    let updatedEarthWorkData:any = {}
    if('isUpdatedVersion' in earthworkDataInDefaultUnit && earthworkDataInDefaultUnit['isUpdatedVersion']){
      updatedEarthWorkData = this.updateUnitInEarthworkData(earthworkDataInDefaultUnit, this.sourceUnit, this.selectedUnit)
    }else{
      updatedEarthWorkData= this.updateUnitConversionInEarthworkData(earthworkDataInDefaultUnit)
    }
    //update earthwork data in configuration list
    var selectedConfig = {}
    this.configurationList.filter(config=>{
      if(config.id == id){
        config.defaultEarthWorkData = earthworkDataInDefaultUnit;
        config.earthWorkData = updatedEarthWorkData
        selectedConfig =config
      }
    })

    this.configTableData.filter(config=>{
      if(config.id == id){  
        config.defaultEarthWorkData = earthworkDataInDefaultUnit;
        config.earthWorkData = updatedEarthWorkData
      }
    })
   
    if (selectedConfig['id'] == this.selectedConfig['id']){
      this.selectedConfig['defaultEarthWorkData'] = earthworkDataInDefaultUnit
      this.selectedConfig['earthWorkData'] = updatedEarthWorkData
    }
    this.updateEarthworkDataInGraph()
    this.sharedService.resultTabComponent.earthWorkCalculationInProgress =false;
    let req = {'earthWorkData':earthworkDataInDefaultUnit}
    this.service.updateEarthWorkData(projectId,layoutId,id,req).then(res=>{})

  }


  formEarthWorkData(data){
    let earthWorkData={};
    earthWorkData['area']={};
    earthWorkData['volume']={};
    earthWorkData['depth']={};

    earthWorkData['area']['cutArea']=parseFloat(data.cutArea.toFixed(4));
    earthWorkData['area']['fillArea']=parseFloat(data.fillArea.toFixed(4));
    earthWorkData['area']['totalDisturbedArea']=parseFloat(data.cutArea.toFixed(4))+parseFloat(data.fillArea.toFixed(4));
    earthWorkData['area']['disturbedPercent']= earthWorkData['area']['totalDisturbedArea'] !=0?  ((earthWorkData['area']['totalDisturbedArea'])/parseFloat(data.arrayArea))*100: 0;
    earthWorkData['area']['totalArrayArea']=parseFloat(data.arrayArea.toFixed(4));

    earthWorkData['volume']['totalGrading']=Math.abs(parseFloat(data.cutVolume.toFixed(4)))+Math.abs(parseFloat(data.fillVolume.toFixed(4)))
    earthWorkData['volume']['cutVolume']=parseFloat(data.cutVolume.toFixed(4));
    earthWorkData['volume']['fillVolume']=parseFloat(data.fillVolume.toFixed(4));
    earthWorkData['volume']['cutFillRatio']= parseFloat(data.fillVolume.toFixed(4)) != 0 ?parseFloat( data.cutVolume.toFixed(4))/parseFloat(data.fillVolume.toFixed(4)) : 0;
    earthWorkData['volume']['totalEarthWork']= Math.abs(parseFloat(data.cutVolume.toFixed(4)))+Math.abs(parseFloat(data.fillVolume.toFixed(4)))
    earthWorkData['volume']['netExportVolume']= -Math.abs(parseFloat(data.cutVolume.toFixed(4)))+parseFloat(data.fillVolume.toFixed(4));

    earthWorkData['depth']['maxCut']=parseFloat(data.maxCutDepth.toFixed(4));
    earthWorkData['depth']['maxFill']=parseFloat(data.maxFillDepth.toFixed(4));
    earthWorkData['depth']['avgCutDepth']=parseFloat(data.avgCutDepth.toFixed(4));
    earthWorkData['depth']['avgFillDepth']=parseFloat(data.avgFillDepth.toFixed(4));
    earthWorkData['depth']['avgDepth']=parseFloat(data.avgDepth.toFixed(4));

return earthWorkData;

  }


  
updateEarthworkDataInGraph(){  
  this.sharedService.resultTabComponent.earthWorkData = this.selectedConfig['earthWorkData']
  this.sharedService.resultTabComponent.loadEarthWorkGraphData();
}

//update array area and calculate disturbed percent  value in earthwork data
updateArrayAreaInEarthwork(arrayArea, id, projectId, layoutId){
  let selectedConfig ={} 
  let disturbedPercent = 0;
  let totalArrayArea = parseFloat((arrayArea/10000).toFixed(4));

  // update totalArrayArea and disturbed percent in configuration list
   this.configurationList.filter(config=>{
    if(config.id == id){
      disturbedPercent =  config.defaultEarthWorkData['area']['totalDisturbedArea'] !=0?  (( config.defaultEarthWorkData['area']['totalDisturbedArea'])/(arrayArea/10000))*100: 0;
      config.defaultEarthWorkData['area']['disturbedPercent'] = disturbedPercent;
      config.defaultEarthWorkData['area']['totalArrayArea'] =totalArrayArea
      // update totalArrayArea value in the selected unit
      config.earthWorkData['area']['totalArrayArea'] =this.selectedUnit.length == 'SI'? totalArrayArea : totalArrayArea*2.471;
      config.earthWorkData['area']['disturbedPercent'] = disturbedPercent
      selectedConfig =config
    }
  })


   // update totalArrayArea and disturbed percent in configuration table data
  this.configTableData.filter(config=>{
    if(config.id == id){  
      config.defaultEarthWorkData['area']['disturbedPercent'] = disturbedPercent;
      config.defaultEarthWorkData['area']['totalArrayArea'] =totalArrayArea
      // update totalArrayArea value in the selected unit
      config.earthWorkData['area']['totalArrayArea'] =this.selectedUnit.length == 'SI'? totalArrayArea : totalArrayArea*2.471;
      config.earthWorkData['area']['disturbedPercent'] = disturbedPercent
    }
  })

  
  this.configurationList = [... this.configurationList]  
  this.configTableData = [... this.configTableData]
 
   // update totalArrayArea and disturbed percent in selected configuration data
  if (selectedConfig['id'] == this.selectedConfig['id']){
    this.selectedConfig['defaultEarthWorkData']['area']['disturbedPercent'] = disturbedPercent;
    this.selectedConfig['defaultEarthWorkData']['area']['totalArrayArea'] =totalArrayArea
    this.selectedConfig['earthWorkData']['area']['disturbedPercent'] = disturbedPercent;
    this.selectedConfig['earthWorkData']['area']['totalArrayArea'] =this.selectedUnit.length == 'SI'? totalArrayArea : totalArrayArea*2.471 ;
  }
  this.updateEarthworkDataInGraph()
  // update totalArrayArea and disturbed percent in backend database
  let req = {'earthWorkData':this.selectedConfig['defaultEarthWorkData']}
  this.service.updateEarthWorkData(projectId,layoutId,id,req).then(res=>{})
}


/** Earth work functionalities - END */


/** Configuration ordering related code - START */ 
initializeSortingSequence(list, isNavConfigList) {
    let requestList = []
    //first sort the data by id and then set the index as order ( for existing data without order )
    list.sort((a, b) => a.id - b.id);
    list = list.map((obj, index) => {
      //starting order from 1 
      obj.sortingSequence = index + 1;
      requestList.push({ 'id': obj.id, 'sortingSequence': obj.sortingSequence })
      return obj;
    });
    if (isNavConfigList) {
      let request = { "updatedSortingSequence": requestList }
      //call api to update order
      this.service.updateConfigurationSortingSequenceOrder(this.defaultAnalysisList['projectId'], this.defaultAnalysisList['layoutId'], request).then(res => { console.log(res) })
    }
    return list
  }

  //update order on change in list
  updateSortingSequenceOrder() {
    let requestList = []

    // update order in list view
    this.configTableData = this.configTableData.map((obj, index) => {
      obj.sortingSequence = index + 1;
      requestList.push({ 'id': obj.id,'sortingSequence': obj.sortingSequence })
      return obj;
    });

    this.configTableData = [...this.configTableData]

    //update order in navigation list
    this.configurationList = this.configurationList.map((obj) => {
      const matchingData = this.configTableData.find((dataObj) => dataObj.id === obj.id);
      if (matchingData) {
        obj.sortingSequence = matchingData.sortingSequence;
      }
      return obj;
    });

    // sort by order
    this.configurationList.sort((a, b) => a.sortingSequence - b.sortingSequence);
    this.configurationList = [...this.configurationList]
    let request = { "updatedSortingSequence": requestList }

    //call api to update order
    this.service.updateConfigurationSortingSequenceOrder(this.defaultAnalysisList['projectId'], this.defaultAnalysisList['layoutId'], request).then(res => { console.log(res) })
    
    //updating the slide index of selected config on order change
    let idx = this.configurationList.findIndex(con=>con.id ===this.selectedConfig.id)
    this.slideIndex = idx+1;

  }

/** Configuration ordering related code - END */ 

}


