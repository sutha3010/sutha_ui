var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var article = this.nextElementSibling;
    if (article.style.display === "block") {
        article.style.display = "none";
    } else {
        article.style.display = "block";
    }
  });
}