$ = function (myPopup) {
    return document.getElementById(myPopup);
  };
  
  var show = function (myPopup) {
    $(myPopup).style.display = "block";
  };
  var hide = function (myPopup) {
    $(myPopup).style.display = "none";
  };
  
  // When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == myPopup) {
    myPopup.style.display = "none";
  }
}




