function toggleSelect() {
    var selectBox = document.getElementById("selectBox");
    selectBox.classList.toggle("active");
}