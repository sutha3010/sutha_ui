// code for sidebar

const sidebar = document.querySelector(".sidebar");
const closeBtn = document.querySelector("#btn");
//Assuming the parent element contains both the closeBtn and sidebar
const parentElement = closeBtn.parentElement;

parentElement.addEventListener("mouseenter", function () {
    sidebar.classList.add("open");
});

sidebar.addEventListener("mouseleave", function (e) {
    const isHoveringParent = parentElement.contains(e.relatedTarget);
    if (!isHoveringParent) {
        sidebar.classList.remove("open");
    }
});

// Accessing all menu items inside the sidebar
const menuItems = document.querySelectorAll(".sidebar .menu-item");
menuItems.forEach(function (menuItem) {
    menuItem.addEventListener("click", function () {
    });
});

// filter icon click event

document.addEventListener("DOMContentLoaded", function() {
    const filterIcon = document.getElementById("filter-icon");
    const contentList = document.getElementById("content-list");

    filterIcon.addEventListener("click", function() {
        if (contentList.style.display === "none" || contentList.style.display === "") {
            contentList.style.display = "block";
        } else {
            contentList.style.display = "none";
        }
    });
});


//to make tab selection

document.addEventListener('DOMContentLoaded', function () {
    const tabs = document.querySelectorAll('.nav-link');
  
    tabs.forEach(tab => {
      tab.addEventListener('click', (e) => {
        e.preventDefault();
  
        // Remove the 'active' class from all tabs and their links
        tabs.forEach(t => {
          t.classList.remove('active');
        });
  
        // Add the 'active' class to the clicked tab
        tab.classList.add('active');
      });
    });
  
    // Initially activate the first tab
    tabs[0].classList.add('active');
  });
  
    //project card code starts here

  // Define your card data (you can have an array of objects)
  const cardData = [
    {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      {
        imageUrl: 'https://developer.terabase.energy/assets/client/images/NoSiteThumbNail-2.jpg',
        title: 'Sur-397_2382',
        city: 'Tirunelveli',
        verticalIconUrl: 'https://developer.terabase.energy/assets/images/icons/common/handle-vertical.svg',
        state: 'Tamil Nadu, IND',
        customer: '',
        pushPinIconUrl: 'https://developer.terabase.energy/assets/main/pushpin-unchecked.9a3642fc4050d05fbcd7.svg',
        createdDate: 'Aug 10, 2023',
        createdBy: 'sutha veni',
      },
      

    // Add more card data as needed

];

const cardContainer = document.querySelector('.project-cards');

 // Get a reference to the card container
 const createCardElement = (data) => {
    const postElement = document.createElement('div');
    postElement.classList.add('card');
    postElement.innerHTML = ` <div class="card border-secondary-subtle custom-card" style="width: 18rem;">
      <img src="${data.imageUrl}" class="card-img-top">
      <div class="card-body img-fluid vstack p-lg-0 card-bg-color">
        <p class="card-text">
        <ul class="clearsky-color clearsky-normal-text text-pd">
        <li class="list-group-item clearsky-color clearsky-sub-header card-title projectLink border-0"><a data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="Sur-397_2382" data-bs-custom-class="custom-tooltip"<a>${data.title}</a></li>
        <li class="list-group-item border-0 clearsky-color clearsky-normal-text" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="Tirunelveli" data-bs-custom-class="custom-tooltip">City: ${data.city}</li>
            <div class="iconRightVertical">
              <img src="${data.verticalIconUrl}">
            </div>
            <li class="list-group-item border-0 clearsky-color clearsky-normal-text"data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="Tamil Nadu, IND" data-bs-custom-class="custom-tooltip">State: ${data.state}</li>
            <li class="list-group-item border-0 clearsky-color clearsky-normal-text"data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="Customer" data-bs-custom-class="custom-tooltip">Customer: ${data.customer}</li>
            <div class="iconRightPushPin">
              <img src="${data.pushPinIconUrl}">
            </div>
            <li class="list-group-item border-0 clearsky-color clearsky-normal-text"data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="Aug 10, 2023" data-bs-custom-class="custom-tooltip">Created on: ${data.createdDate}</li>
            <li class="list-group-item border-0 clearsky-color clearsky-normal-text"data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="sutha veni" data-bs-custom-class="custom-tooltip">Created by: ${data.createdBy}</li>
          </ul>
        </p>
      </div>
    </div>`;
    
    return postElement;
  };

const renderCards = () => {
    cardData.forEach((data) => {
      const cardElement = createCardElement(data);
      cardContainer.appendChild(cardElement);
    });
  };
  
  // Call the renderCards function to generate the card elements
  renderCards();

// code for tooltip
  function initTooltips() {
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach((tooltip) => {
      new bootstrap.Tooltip(tooltip);
    });
  }
  
  // Call the initTooltips function to initialize the tooltips
  initTooltips();
  
  //scrollbar will be active only when mouse enters the div

  const scroll = document.getElementById('scroll');

  scroll.addEventListener('mouseenter', () => {
    scroll.classList.add('hovered');
  });
  
  scroll.addEventListener('mouseleave', () => {
    scroll.classList.remove('hovered');
  });
  
  