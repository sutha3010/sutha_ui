def hello():
    print("Hello World")
    print(hello())

# #Function with parameter
def add10(x):
    return x+10

def even_odd(x):
    if x%2==0:
        print(x, " is even")
    else:
        print(x, " is odd")
    even_odd(5)

#lambda functions
g = lambda x: x*x*x
print(g(7))


#lambda functions with filter
li = [5, 7, 22, 97, 54, 62, 77, 23, 73, 61]
1
final_list = list(filter(lambda x: (x%2 != 0) , li))
print(final_list)
[5, 7, 97, 77, 23, 73, 61]


#lambda functions with map
li = [5, 7, 22, 97, 54, 62, 77, 23, 73, 61]
final_list = list(map(lambda x: x*2 , li))
print(final_list)
[10, 14, 44, 194, 108, 124, 154, 46, 146, 122]
from functools import reduce
li = [5, 8, 10, 20, 50, 100]
sum = reduce((lambda x, y: x + y), li)
print (sum)
