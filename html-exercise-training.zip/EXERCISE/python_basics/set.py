#Set in Python
s1={1,"a",True,2,"b",False}
print(s1)


s2={1,"a",True,2,"b",False}
s2.add("Hello")
print(s2)

s3={1,"a",True,2,"b",False}
s3.update([10,20,30])
print(s3)

s4={1,"a",True,2,"b",False}
s4.remove("b")
print(s4)


s1 = {1,2,3,4,5,6}
s2 = {5,6,7,8,9}
print(s1.intersection(s2))
