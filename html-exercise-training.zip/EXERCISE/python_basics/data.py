#Data-Type
a=10

print(type(a))

a1=10.5
print(type(a1))


a2="sparta"
print(type(a2))


a3=True
print(type(a3))


a4=3+4j
print(type(a4))


