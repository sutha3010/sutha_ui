#Arithmetic Operators
a=10
b=20
print(a+b)

print(a-b)

print(a*b)

print(a/b)




