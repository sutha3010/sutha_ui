#Dictionary in Python
fruit={"Apple":10,"Orange":20,"Banana":30,"Guava":40}
print(fruit.keys())


fruit={"Apple":10,"Orange":20,"Banana":30,"Guava":40}
print(fruit.values())


fruit={"Apple":10,"Orange":20,"Banana":30,"Guava":40}
fruit["Mango"]=50

fruit3={"Apple":10,"Orange":20,"Banana":30,"Guava":40,"Mango":50}
fruit3["Apple"]=100
print(fruit3)

fruit1={"Apple":10,"Orange":20}
fruit2={"Banana":30,"Guava":40}
print(fruit1.update(fruit2))

fruit={"Apple":10,"Orange":20,"Banana":30,"Guava":40}
fruit.pop("Orange")
print(fruit)