#simple for loop
fruits = ["apple","mango","banana"]
for i in fruits:
    print(i)


#nested for loop
color=["blue","green","yellow"]
item=["book","ball","chair"]
for i in color:
    for j in item:
        print(i,j)
