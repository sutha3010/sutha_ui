var data = {
    "images": [{
      "bannerImg1": "IMAGES/pic1.jpg"
    },
    {
     "bannerImg1": "IMAGES/pic2.jpg"
      },
      {
        "bannerImg1": "IMAGES/pic3.jpg"
      },
      {
        "bannerImg1": "IMAGES/pic4.jpg"
      },
      {
        "bannerImg1": "IMAGES/pic5.jpg"
      },
       {
        "bannerImg1": "IMAGES/pic6.jpg"
      },
    {"bannerImg1" : "IMAGES/pic1.jpg"
    }]
  };
  data.images.forEach( function(obj) {
    var img = new Image();
    img.src = obj.bannerImg1;
    img.setAttribute("class", "ImgThumbnail");
    img.setAttribute("alt", "effy");
    document.getElementById("image").appendChild(img);
  });

var modalEle = document.querySelector(".modal");
var modalImage = document.querySelector(".modalImage");
Array.from(document.querySelectorAll(".ImgThumbnail")).forEach(item => {
item.addEventListener("click", event => {
modalEle.style.display = "block";
modalImage.src = event.target.src;
});
});
document.querySelector(".close").addEventListener("click", () => {
modalEle.style.display = "none";
});