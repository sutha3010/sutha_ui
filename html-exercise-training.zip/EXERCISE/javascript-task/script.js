//Create a function for reversing a string
function rev() {
	var x = document.getElementById("myText").value;
	strig1 = x.split('').reverse().join('')
	document.getElementById("demo").innerHTML = strig1;
}



// Write a function to calculate number of days for Diwali

function cal() {
	// One day Time in ms (milliseconds)
	var y = document.getElementById('date').value;

	var one_day = 1000 * 60 * 60 * 24

	// To set present_dates to two variables
	var present_date = new Date(y);

	// 0-11 is Month in JavaScript
	var diwali_day = new Date(present_date.getFullYear(), 10, 12)

	// To Calculate next year's diwali if passed already.
	if (present_date.getMonth() > 10 && present_date.getDate() > 12)
		diwali_day.setFullYear(diwali_day.getFullYear() + 1)

	// To Calculate the result in milliseconds and then converting into days
	var Result = Math.round(diwali_day.getTime() - present_date.getTime()) / (one_day);

	// To remove the decimals from the (Result) resulting days value
	var Final_Result = Result.toFixed(0);

	//To display the final_result value
	document.getElementById("diwali").innerHTML = Final_Result + "Days remaining for diwali";

}



//Write a function to create a countdown for specified date

function count() {

	var date1 = document.getElementById("date3").value;
	var deadline = new Date(date1).getTime();


	// var deadline = new Date("dec 31, 2022 15:37:25").getTime();

	var x = setInterval(function () {

		var now = new Date().getTime();
		var t = deadline - now;
		var days = Math.floor(t / (1000 * 60 * 60 * 24));
		var hours = Math.floor((t % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
		var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
		var seconds = Math.floor((t % (1000 * 60)) / 1000);
		document.getElementById("day").innerHTML = days;
		document.getElementById("hour").innerHTML = hours;
		document.getElementById("minute").innerHTML = minutes;
		document.getElementById("second").innerHTML = seconds;
		if (t < 0) {
			clearInterval(x);
			document.getElementById("dates").innerHTML = "TIME UP";
			document.getElementById("day").innerHTML = '0';
			document.getElementById("hour").innerHTML = '0';
			document.getElementById("minute").innerHTML = '0';
			document.getElementById("second").innerHTML = '0';
		}
	}, 1000);

}

//Create Native methods for following :

// A. Define removeAt(array,element_to_remove) function on Array
//Object that will remove specified element from array

function remove_at() {
var input = document.getElementById('remove_input').value;
	var myArray = input.split('');
	var output = myArray.shift();
	document.getElementById('remove_output1').innerHTML = "Array : " + myArray;
	document.getElementById('remove_output2').innerHTML = "Element Removed : " + output;
	}
	
	
//4. B. Define a function findInArray(array,element_to_find) on Array object for searchingin array using binary search
	
	function find() {
	var find_input = document.getElementById('find_input').value;
	var array = find_input.split('');
	var found = array.find(function (element) {
	return element > 6;
	});
	
// Printing desired values.
	document.getElementById("find_output1").innerHTML = found + " is the first element greater than 6";
	}
	
	
//4. C. Define a function getMonthName(date) on Date Object for gettingtextual representation of month
	
	function month() {
	let d = document.getElementById("find_month").value;
	let mon = new Date(d);
	const monthNames = ["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"
	];
	
	document.getElementById("month_output").innerHTML = "the number that you typed has the month is : " + monthNames[mon.getMonth()];
	}
	
	
//4. D. Define a function repeat(string,numberOfRepeats) on String Object to repeat a string a specified times
	
	function repeat() {
	var str = document.getElementById("string").value;
	var num = document.getElementById("numb").value;
	var repeatedString = " ";
	while (num > 0) {
	repeatedString += str + ', ';
	num--;
	}
	document.getElementById("repeat_output").innerHTML = "The repeated strings are : " + repeatedString;
	}
	
	

//Bubble sort Implementation using Javascript

function bubble1() {
var arr = [222, 145, 20, 9503, 900];
	for (var i = 0; i < arr.length; i++) {
	for (var j = 0; j < (arr.length - i - 1); j++) {
		if (arr[j] < arr[j + 1]) {
	var temp = arr[j]
	arr[j] = arr[j + 1]
	arr[j + 1] = temp
	}
	}
}
	document.getElementById("bubble_result").innerHTML = "After sorting using Bubble sort algorithm : " + arr;
}


//Write a function to find value of bn, where n is exponent and b is base.
//Accept b and n as parameters and display result

function power(){
	var Base = document.getElementById('base_input').value;
      var Exponent = document.getElementById('exponent_input').value;
      var answer = Math.pow(Base, Exponent);
	  document.getElementById("power_result").innerHTML="answer is "+ answer;

}
//function to convert amount to coins.

function amountTocoins() {
	// var originalNum = +input.value;
	var num = document.getElementById('amount').value;
	var arr=(51,[20,10,,5,2,1]);
	var str = '';
	
	for (var i=0; i<arr.length; i++) {
	  if (num>=arr[i]) {
		num = num - arr[i];
		str = str + arr[i] + ',';
		i--;
	  }
	}
	
	// input.value = 'Amount:'+originalNum + '  Coins: '+str.substring(0, str.length - 1);   
	document.getElementById("results").innerHTML = "The Amount is :" +num +"the Coin is :" +arr;
  }
  

  function fizz(){
	var num = document.getElementById('fizz_input').value;

	for (var i = 1; i <= num; i++) 
	{
		if (i % 15 == 0)
		 {
			
		document.write("FizzBuzz" + "<br><br>");
	    }
		else if (i % 3 == 0)
		{
			
		document.write("Fizz" + "<br><br>");
	    }
		else if (i % 5 == 0)
		{			
		   document.write("Buzz" + "<br><br>");
	    }

		else {
			document.write(i + "<br><br>");
		}
	}
	
  }


  function count_hours()
  {
  var hours_day =  document.getElementById('hours_input1').value;
  var hours_month =  document.getElementById('hours_input2').value;  
  var hours_year =  document.getElementById('hours_input3').value;
  
  dt1 = new Date();
  dt2 = new Date(hours_month+hours_day+", "+hours_year+" 11:13:00");
  function diff_hours(dt2, dt1) 
  {
 
   var diff =(dt2.getTime() - dt1.getTime()) / 1000;
   diff /= (60 * 60);
   return Math.abs(Math.round(diff));
   
  }
  var output = diff_hours(dt1, dt2);
  document.getElementById('hours_output').innerHTML =  output+"Hours";

}


// find alphabetize function


function find_string(){
	var input =  document.getElementById('string_input').value;
  
	function alphabetize_string(input) 
  {
	  
  return input.split('').sort().join('').trim();
  
  }
  var output = alphabetize_string(input);
	document.getElementById('string_output').innerHTML =  output;
  }
  
  // find IP valid Address
  
  function valid_IP(){
	var input = document.getElementById("IP_input").value;
	  var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
	  if(input.match(ipformat))
	  {
		  document.getElementById("IP_output").innerHTML="Valid IP Address"
	  }
	  else
	  {
		  document.getElementById("IP_output").innerHTML="In-Valid IP Address"
	  }
  }

