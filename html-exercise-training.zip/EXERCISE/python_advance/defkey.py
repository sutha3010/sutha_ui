def sum(a,b):
    return a + b

a = 1
b = 2
c = sum(a,b)
print(c)