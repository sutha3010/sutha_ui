let signup = document.querySelector(".signup");
let login = document.querySelector(".login");
// let slider = document.querySelector(".slider");
let formSection = document.querySelector(".form-section");
let user= document.getElementById("name").value;
let pass= document.getElementById("pass").value;

