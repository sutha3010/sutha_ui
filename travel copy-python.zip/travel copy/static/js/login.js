const pass_field = document.querySelector(".pass");
const showBtn = document.querySelector(".show");
showBtn.addEventListener("click", function () {
  if (pass_field.type === "password") {
    pass_field.type = "text";
    showBtn.textContent = "HIDE";
    showBtn.style.color = "#D052F6";
  } else {
    pass_field.type = "password";
    showBtn.textContent = "SHOW";
    showBtn.style.color = "#222";
  }
});


function login() {
  let name = document.getElementById('name').value;
  let pass = document.getElementById('pass').value;

  
  if (name == 'admin' && pass == '123')
   {
    encode_uname=window.btoa(name);
    encode_upass=window.btoa(pass);

    sessionStorage.setItem("uname", encode_uname);
    sessionStorage.setItem("upass", encode_upass);

    alert('Logged in successfully');
    window.location.href = 'index.html';
  } else {
    alert('fail');
  }
}

function register() {
  let name = document.getElementById('name').value;
  let email = document.getElementById('email').value;
  let password = document.getElementById('pass').value;
  let mobile = document.getElementById('mob').value;
  let location = document.getElementById('loct').value;
  
console.log(location);
  alert('Registered successfully');
    window.location.href = 'index.html';
  // } else {
  //   alert('fail');
  // }

}



let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function () {
  sidebar.classList.toggle("active");
  if (sidebar.classList.contains("active")) {
    sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
  } else
    sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
