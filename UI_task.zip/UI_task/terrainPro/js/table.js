$(document).ready(function() {
    $('#dataTable').DataTable({
        paging: true,  
        pageLength: 10,  
    });
});