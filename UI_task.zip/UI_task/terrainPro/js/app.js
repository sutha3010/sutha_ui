// function for the ribbon
function showSubRibbon(subRibbonId) {
  var subRibbons = document.querySelectorAll(".sub-ribbon");
  for (var i = 0; i < subRibbons.length; i++) {
    subRibbons[i].style.display = "none";
  }
  var subRibbon = document.getElementById(subRibbonId);
  subRibbon.style.display = "flex";
}




// JavaScript function to toggle the content box
function toggleContent() {
var contentBox = document.getElementById("content-box");
if (contentBox.style.display === "none") {
  contentBox.style.display = "block";
} else {
  contentBox.style.display = "none";
}
}

//darkmode code
function toggleMode() {
const container = document.querySelector('.fixed-container');
container.classList.toggle('dark-mode');

// Store the dark mode preference in local storage
const isDarkMode = container.classList.contains('dark-mode');
localStorage.setItem('darkMode', isDarkMode);
}
const toggleModeBtn = document.getElementById('toggleModeBtn');
toggleModeBtn.addEventListener('click', toggleMode);

document.getElementById('toggleModeBtn').addEventListener('change', function() {
document.body.classList.toggle('dark-mode');

//Check if dark mode preference exists in local storage
  const darkMode = localStorage.getItem('darkMode');
  if (darkMode === 'true') {
    // If dark mode preference is true, add dark-mode class to container
    document.querySelector('.fixed-container').classList.add('dark-mode');
    toggleModeBtn.checked = true;
  }
});



// table code
const showDataTableBtn = document.getElementById('showDataTableBtn');
showDataTableBtn.addEventListener('click', () => {
// Use AJAX to load the DataTable content from the separate file
const xhr = new XMLHttpRequest();
xhr.open('GET', 'table.html', true);
xhr.onreadystatechange = function () {
  if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
    const dataTableContent = xhr.responseText;
    
    // Insert the content into the middle layout
    const dataTableContainer = document.getElementById('dataTableContainer');
    dataTableContainer.innerHTML = dataTableContent;
    
    // Initialize DataTables and add pagination
    $(document).ready(function() {
      $('#dataTable').DataTable();
    });
  }
};
xhr.send();
});


//right layout code 
function showElaborateImage(image) {
const elaborateImageContainer = document.querySelector('.elaborate-image-container');
const elaborateImage = elaborateImageContainer.querySelector('.elaborate-image');
const overlay = document.querySelector('.overlay');

const imageURL = image.src;
elaborateImage.src = imageURL;

elaborateImageContainer.style.display = 'block';
overlay.style.display = 'block';
}

function hideElaborateImage() {
const elaborateImageContainer = document.querySelector('.elaborate-image-container');
const overlay = document.querySelector('.overlay');


elaborateImageContainer.style.display = 'none';
overlay.style.display = 'none';
}

// const showDataTableBtn = document.getElementById("showDataTableBtn");
const popupContainer = document.getElementById("popupContainer");
const closePopupBtn = document.getElementById("closePopupBtn");
const tableIframe = document.getElementById("tableIframe");

showDataTableBtn.addEventListener("click", () => {
const tableURL = "table.html"; // Replace with the actual path to your table HTML file
tableIframe.src = tableURL;
popupContainer.style.display = "flex";
});

closePopupBtn.addEventListener("click", () => {
popupContainer.style.display = "none";
tableIframe.src = "";
});


document.getElementById("showDataTableBtn").addEventListener("click", function() {
document.getElementById("popupContainer").style.display = "flex";
});

document.getElementById("closePopupBtn").addEventListener("click", function() {
document.getElementById("popupContainer").style.display = "none";
});
