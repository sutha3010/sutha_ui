const checkbox = document.getElementById("numericCheckbox");

checkbox.addEventListener("keypress", function (event) {
  const keyCode = event.keyCode;

  // Allow only numbers (0-9) and special keys like backspace
  if (keyCode < 48 || keyCode > 57) {
    event.preventDefault();
  }
});

// code to turn the textbox as red when clear all the

// function validateTextbox() {
//     const textbox = document.querySelector(".custom-textbox input");
//     const textboxWrapper = document.querySelector(".custom-textbox");
  
    
//     if (textbox.value.trim() === "") {
//       textboxWrapper.classList.add("error");
//     } else {
//       textboxWrapper.classList.remove("error");
//     }
//   }


  const input1 = document.getElementById('input1');
  const input2 = document.getElementById('input2');
  
  input1.addEventListener('input', function() {
    const text = input1.value;
    input2.value = text;
  });



  function validateTextbox(inputId) {
    // template literal (#${inputId}) to select the textbox element based on its ID.
    const textbox = document.querySelector(`#${inputId}`);
    // textbox is wrapped inside a container element.
    const textboxWrapper = textbox.parentNode;
    const inputValue = textbox.value.trim();
    
    if (inputValue === "") {
      textboxWrapper.classList.add("error");
      showErrorMessage(inputId, 'This field is required.');
    } else if (!/^\d{0,9}$/.test(inputValue)) {
      textbox.value = inputValue.slice(0, 9);
      textbox.classList.add('error');
      showErrorMessage(inputId, 'Please enter only 9 digits.');
    } else {
      textbox.classList.remove('error');
      hideErrorMessage(inputId);
    }
  }
  
  function showErrorMessage(inputId, errorMessage) {
    const errorElement = document.getElementById(inputId + '-error');
    errorElement.textContent = errorMessage;
  }
  
  function hideErrorMessage(inputId) {
    const errorElement = document.getElementById(inputId + '-error');
    errorElement.textContent = '';
  }
  